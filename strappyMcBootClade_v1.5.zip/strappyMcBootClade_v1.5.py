import math
import random
import sys
import time

def popGene(popFile):
    '''To run strappyMcBootClade type the following into a unix interpreter:
    
    python strappyMcBootClade_vxx.py <popFile.txt>
    
    where "xx" refers to the version number.
    
    strappyMcBootClade only considers codons with 2 or fewer changes between them and 2 or 
    fewer alleles at the codon of interest. For codons with 2 changes, pathway 
    with fewest number of nonsynonymous changes is assumed. Sites with missing 
    data are partially ignored by removing that sample from the codon-by-codon 
    analysis. Codons with missing data are assumed to have 0.71875 synonymous 
    sites and 2.28125 nonsynonymous sites. Missing nucleotides should be 
    specified by 'N', missing amino acids will be specified by 'X'.
    
    Citation:
    
    Sharbrough et al. Inefficient purifying selection and variation in 
    functional constraint drives accelerated but heterogeneous accumulation 
    of harmful mutations in asexual lineages of a freshwater snail. In review.
    '''
    
    t1 = time.time()
    infile2 = open(popFile,'r')
    geneticCodes = {'standard':{"TTT":"F",	"TTC":"F",	"TTA":"L",	"TTG":"L",	"TCT":"S",	"TCC":"S",	"TCA":"S",	"TCG":"S",	"TAT":"Y",	"TAC":"Y",	"TAA":"*",	"TAG":"*",	"TGT":"C",	"TGC":"C",	"TGA":"*",	"TGG":"W",	"CTT":"L",	"CTC":"L",	"CTA":"L",	"CTG":"L",	"CCT":"P",	"CCC":"P",	"CCA":"P",	"CCG":"P",	"CAT":"H",	"CAC":"H",	"CAA":"Q",	"CAG":"Q",	"CGT":"R",	"CGC":"R",	"CGA":"R",	"CGG":"R",	"ATT":"I",	"ATC":"I",	"ATA":"I",	"ATG":"M",	"ACT":"T",	"ACC":"T",	"ACA":"T",	"ACG":"T",	"AAT":"N",	"AAC":"N",	"AAA":"K",	"AAG":"K",	"AGT":"S",	"AGC":"S",	"AGA":"R",	"AGG":"R",	"GTT":"V",	"GTC":"V",	"GTA":"V",	"GTG":"V",	"GCT":"A",	"GCC":"A",	"GCA":"A",	"GCG":"A",	"GAT":"D",	"GAC":"D",	"GAA":"E",	"GAG":"E",	"GGT":"G",	"GGC":"G",	"GGA":"G",	"GGG":"G"},'invertebrateMt':{'CTT': 'L', 'TAG': '*', 'ACA': 'T', 'ACG': 'T', 'ATC': 'I', 'AAC': 'N', 'ATA': 'M', 'AGG': 'S', 'CCT': 'P', 'ACT': 'T', 'AGC': 'S', 'AAG': 'K', 'AGA': 'S', 'CAT': 'H', 'AAT': 'N', 'ATT': 'I', 'CTG': 'L', 'CTA': 'L', 'CTC': 'L', 'CAC': 'H', 'AAA': 'K', 'CCG': 'P', 'AGT': 'S', 'CCA': 'P', 'CAA': 'Q', 'CCC': 'P', 'TAT': 'Y', 'GGT': 'G', 'TGT': 'C', 'CGA': 'R', 'CAG': 'Q', 'TCT': 'S', 'GAT': 'D', 'CGG': 'R', 'TTT': 'F', 'TGC': 'C', 'GGG': 'G', 'TGA': 'W', 'GGA': 'G', 'TGG': 'W', 'GGC': 'G', 'TAC': 'Y', 'TTC': 'F', 'TCG': 'S', 'TTA': 'L', 'TTG': 'L', 'TCC': 'S', 'ACC': 'T', 'TAA': '*', 'GCA': 'A', 'GTA': 'V', 'GCC': 'A', 'GTC': 'V', 'GCG': 'A', 'GTG': 'V', 'GAG': 'E', 'GTT': 'V', 'GCT': 'A', 'GAC': 'D', 'CGT': 'R', 'GAA': 'E', 'TCA': 'S', 'ATG': 'M', 'CGC': 'R'},'vertebrateMt':{'CTT': 'L', 'TAG': '*', 'ACA': 'T', 'ACG': 'T', 'ATC': 'I', 'AAC': 'N', 'ATA': 'M', 'AGG': '*', 'CCT': 'P', 'ACT': 'T', 'AGC': 'S', 'AAG': 'K', 'AGA': '*', 'CAT': 'H', 'AAT': 'N', 'ATT': 'I', 'CTG': 'L', 'CTA': 'L', 'CTC': 'L', 'CAC': 'H', 'AAA': 'K', 'CCG': 'P', 'AGT': 'S', 'CCA': 'P', 'CAA': 'Q', 'CCC': 'P', 'TAT': 'Y', 'GGT': 'G', 'TGT': 'C', 'CGA': 'R', 'CAG': 'Q', 'TCT': 'S', 'GAT': 'D', 'CGG': 'R', 'TTT': 'F', 'TGC': 'C', 'GGG': 'G', 'TGA': 'W', 'GGA': 'G', 'TGG': 'W', 'GGC': 'G', 'TAC': 'Y', 'TTC': 'F', 'TCG': 'S', 'TTA': 'L', 'TTG': 'L', 'TCC': 'S', 'ACC': 'T', 'TAA': '*', 'GCA': 'A', 'GTA': 'V', 'GCC': 'A', 'GTC': 'V', 'GCG': 'A', 'GTG': 'V', 'GAG': 'E', 'GTT': 'V', 'GCT': 'A', 'GAC': 'D', 'CGT': 'R', 'GAA': 'E', 'TCA': 'S', 'ATG': 'M', 'CGC': 'R'}, 'yeastMt':{'CTT': 'T', 'TAG': '*', 'ACA': 'T', 'ACG': 'T', 'ATC': 'I', 'AAC': 'N', 'ATA': 'M', 'AGG': 'R', 'CCT': 'P', 'ACT': 'T', 'AGC': 'S', 'AAG': 'K', 'AGA': 'R', 'CAT': 'H', 'AAT': 'N', 'ATT': 'I', 'CTG': 'T', 'CTA': 'T', 'CTC': 'T', 'CAC': 'H', 'AAA': 'K', 'CCG': 'P', 'AGT': 'S', 'CCA': 'P', 'CAA': 'Q', 'CCC': 'P', 'TAT': 'Y', 'GGT': 'G', 'TGT': 'C', 'CGA': 'R', 'CAG': 'Q', 'TCT': 'S', 'GAT': 'D', 'CGG': 'R', 'TTT': 'F', 'TGC': 'C', 'GGG': 'G', 'TGA': 'W', 'GGA': 'G', 'TGG': 'W', 'GGC': 'G', 'TAC': 'Y', 'TTC': 'F', 'TCG': 'S', 'TTA': 'L', 'TTG': 'L', 'TCC': 'S', 'ACC': 'T', 'TAA': '*', 'GCA': 'A', 'GTA': 'V', 'GCC': 'A', 'GTC': 'V', 'GCG': 'A', 'GTG': 'V', 'GAG': 'E', 'GTT': 'V', 'GCT': 'A', 'GAC': 'D', 'CGT': 'R', 'GAA': 'E', 'TCA': 'S', 'ATG': 'M', 'CGC': 'R'}, 'coelenterateMt':{'CTT': 'L', 'TAG': '*', 'ACA': 'T', 'ACG': 'T', 'ATC': 'I', 'AAC': 'N', 'ATA': 'I', 'AGG': 'R', 'CCT': 'P', 'ACT': 'T', 'AGC': 'S', 'AAG': 'K', 'AGA': 'R', 'CAT': 'H', 'AAT': 'N', 'ATT': 'I', 'CTG': 'L', 'CTA': 'L', 'CTC': 'L', 'CAC': 'H', 'AAA': 'K', 'CCG': 'P', 'AGT': 'S', 'CCA': 'P', 'CAA': 'Q', 'CCC': 'P', 'TAT': 'Y', 'GGT': 'G', 'TGT': 'C', 'CGA': 'R', 'CAG': 'Q', 'TCT': 'S', 'GAT': 'D', 'CGG': 'R', 'TTT': 'F', 'TGC': 'C', 'GGG': 'G', 'TGA': 'W', 'GGA': 'G', 'TGG': 'W', 'GGC': 'G', 'TAC': 'Y', 'TTC': 'F', 'TCG': 'S', 'TTA': 'L', 'TTG': 'L', 'TCC': 'S', 'ACC': 'T', 'TAA': '*', 'GCA': 'A', 'GTA': 'V', 'GCC': 'A', 'GTC': 'V', 'GCG': 'A', 'GTG': 'V', 'GAG': 'E', 'GTT': 'V', 'GCT': 'A', 'GAC': 'D', 'CGT': 'R', 'GAA': 'E', 'TCA': 'S', 'ATG': 'M', 'CGC': 'R'},'ciliateNuc':{'CTT': 'L', 'TAG': 'Q', 'ACA': 'T', 'ACG': 'T', 'ATC': 'I', 'AAC': 'N', 'ATA': 'I', 'AGG': 'R', 'CCT': 'P', 'ACT': 'T', 'AGC': 'S', 'AAG': 'K', 'AGA': 'R', 'CAT': 'H', 'AAT': 'N', 'ATT': 'I', 'CTG': 'L', 'CTA': 'L', 'CTC': 'L', 'CAC': 'H', 'AAA': 'K', 'CCG': 'P', 'AGT': 'S', 'CCA': 'P', 'CAA': 'Q', 'CCC': 'P', 'TAT': 'Y', 'GGT': 'G', 'TGT': 'C', 'CGA': 'R', 'CAG': 'Q', 'TCT': 'S', 'GAT': 'D', 'CGG': 'R', 'TTT': 'F', 'TGC': 'C', 'GGG': 'G', 'TGA': '*', 'GGA': 'G', 'TGG': 'W', 'GGC': 'G', 'TAC': 'Y', 'TTC': 'F', 'TCG': 'S', 'TTA': 'L', 'TTG': 'L', 'TCC': 'S', 'ACC': 'T', 'TAA': 'Q', 'GCA': 'A', 'GTA': 'V', 'GCC': 'A', 'GTC': 'V', 'GCG': 'A', 'GTG': 'V', 'GAG': 'E', 'GTT': 'V', 'GCT': 'A', 'GAC': 'D', 'CGT': 'R', 'GAA': 'E', 'TCA': 'S', 'ATG': 'M', 'CGC': 'R'},'echinodermMt':{'CTT': 'L', 'TAG': '*', 'ACA': 'T', 'ACG': 'T', 'ATC': 'I', 'AAC': 'N', 'ATA': 'I', 'AGG': 'S', 'CCT': 'P', 'ACT': 'T', 'AGC': 'S', 'AAG': 'K', 'AGA': 'S', 'CAT': 'H', 'AAT': 'N', 'ATT': 'I', 'CTG': 'L', 'CTA': 'L', 'CTC': 'L', 'CAC': 'H', 'AAA': 'N', 'CCG': 'P', 'AGT': 'S', 'CCA': 'P', 'CAA': 'Q', 'CCC': 'P', 'TAT': 'Y', 'GGT': 'G', 'TGT': 'C', 'CGA': 'R', 'CAG': 'Q', 'TCT': 'S', 'GAT': 'D', 'CGG': 'R', 'TTT': 'F', 'TGC': 'C', 'GGG': 'G', 'TGA': 'W', 'GGA': 'G', 'TGG': 'W', 'GGC': 'G', 'TAC': 'Y', 'TTC': 'F', 'TCG': 'S', 'TTA': 'L', 'TTG': 'L', 'TCC': 'S', 'ACC': 'T', 'TAA': '*', 'GCA': 'A', 'GTA': 'V', 'GCC': 'A', 'GTC': 'V', 'GCG': 'A', 'GTG': 'V', 'GAG': 'E', 'GTT': 'V', 'GCT': 'A', 'GAC': 'D', 'CGT': 'R', 'GAA': 'E', 'TCA': 'S', 'ATG': 'M', 'CGC': 'R'}, 'euplotidNuc':{'CTT': 'L', 'TAG': '*', 'ACA': 'T', 'ACG': 'T', 'ATC': 'I', 'AAC': 'N', 'ATA': 'I', 'AGG': 'R', 'CCT': 'P', 'ACT': 'T', 'AGC': 'S', 'AAG': 'K', 'AGA': 'R', 'CAT': 'H', 'AAT': 'N', 'ATT': 'I', 'CTG': 'L', 'CTA': 'L', 'CTC': 'L', 'CAC': 'H', 'AAA': 'K', 'CCG': 'P', 'AGT': 'S', 'CCA': 'P', 'CAA': 'Q', 'CCC': 'P', 'TAT': 'Y', 'GGT': 'G', 'TGT': 'C', 'CGA': 'R', 'CAG': 'Q', 'TCT': 'S', 'GAT': 'D', 'CGG': 'R', 'TTT': 'F', 'TGC': 'C', 'GGG': 'G', 'TGA': 'C', 'GGA': 'G', 'TGG': 'W', 'GGC': 'G', 'TAC': 'Y', 'TTC': 'F', 'TCG': 'S', 'TTA': 'L', 'TTG': 'L', 'TCC': 'S', 'ACC': 'T', 'TAA': '*', 'GCA': 'A', 'GTA': 'V', 'GCC': 'A', 'GTC': 'V', 'GCG': 'A', 'GTG': 'V', 'GAG': 'E', 'GTT': 'V', 'GCT': 'A', 'GAC': 'D', 'CGT': 'R', 'GAA': 'E', 'TCA': 'S', 'ATG': 'M', 'CGC': 'R'}, 'bacterial':{'CTT': 'L', 'TAG': '*', 'ACA': 'T', 'ACG': 'T', 'ATC': 'I', 'AAC': 'N', 'ATA': 'I', 'AGG': 'R', 'CCT': 'P', 'ACT': 'T', 'AGC': 'S', 'AAG': 'K', 'AGA': 'R', 'CAT': 'H', 'AAT': 'N', 'ATT': 'I', 'CTG': 'L', 'CTA': 'L', 'CTC': 'L', 'CAC': 'H', 'AAA': 'K', 'CCG': 'P', 'AGT': 'S', 'CCA': 'P', 'CAA': 'Q', 'CCC': 'P', 'TAT': 'Y', 'GGT': 'G', 'TGT': 'C', 'CGA': 'R', 'CAG': 'Q', 'TCT': 'S', 'GAT': 'D', 'CGG': 'R', 'TTT': 'F', 'TGC': 'C', 'GGG': 'G', 'TGA': '*', 'GGA': 'G', 'TGG': 'W', 'GGC': 'G', 'TAC': 'Y', 'TTC': 'F', 'TCG': 'S', 'TTA': 'L', 'TTG': 'L', 'TCC': 'S', 'ACC': 'T', 'TAA': '*', 'GCA': 'A', 'GTA': 'V', 'GCC': 'A', 'GTC': 'V', 'GCG': 'A', 'GTG': 'V', 'GAG': 'E', 'GTT': 'V', 'GCT': 'A', 'GAC': 'D', 'CGT': 'R', 'GAA': 'E', 'TCA': 'S', 'ATG': 'M', 'CGC': 'R'},'yeastNuc':{'CTT': 'L', 'TAG': '*', 'ACA': 'T', 'ACG': 'T', 'ATC': 'I', 'AAC': 'N', 'ATA': 'I', 'AGG': 'R', 'CCT': 'P', 'ACT': 'T', 'AGC': 'S', 'AAG': 'K', 'AGA': 'R', 'CAT': 'H', 'AAT': 'N', 'ATT': 'I', 'CTG': 'S', 'CTA': 'L', 'CTC': 'L', 'CAC': 'H', 'AAA': 'K', 'CCG': 'P', 'AGT': 'S', 'CCA': 'P', 'CAA': 'Q', 'CCC': 'P', 'TAT': 'Y', 'GGT': 'G', 'TGT': 'C', 'CGA': 'R', 'CAG': 'Q', 'TCT': 'S', 'GAT': 'D', 'CGG': 'R', 'TTT': 'F', 'TGC': 'C', 'GGG': 'G', 'TGA': '*', 'GGA': 'G', 'TGG': 'W', 'GGC': 'G', 'TAC': 'Y', 'TTC': 'F', 'TCG': 'S', 'TTA': 'L', 'TTG': 'L', 'TCC': 'S', 'ACC': 'T', 'TAA': '*', 'GCA': 'A', 'GTA': 'V', 'GCC': 'A', 'GTC': 'V', 'GCG': 'A', 'GTG': 'V', 'GAG': 'E', 'GTT': 'V', 'GCT': 'A', 'GAC': 'D', 'CGT': 'R', 'GAA': 'E', 'TCA': 'S', 'ATG': 'M', 'CGC': 'R'}, 'ascidianMt':{'CTT': 'L', 'TAG': '*', 'ACA': 'T', 'ACG': 'T', 'ATC': 'I', 'AAC': 'N', 'ATA': 'M', 'AGG': 'G', 'CCT': 'P', 'ACT': 'T', 'AGC': 'S', 'AAG': 'K', 'AGA': 'G', 'CAT': 'H', 'AAT': 'N', 'ATT': 'I', 'CTG': 'L', 'CTA': 'L', 'CTC': 'L', 'CAC': 'H', 'AAA': 'K', 'CCG': 'P', 'AGT': 'S', 'CCA': 'P', 'CAA': 'Q', 'CCC': 'P', 'TAT': 'Y', 'GGT': 'G', 'TGT': 'C', 'CGA': 'R', 'CAG': 'Q', 'TCT': 'S', 'GAT': 'D', 'CGG': 'R', 'TTT': 'F', 'TGC': 'C', 'GGG': 'G', 'TGA': 'W', 'GGA': 'G', 'TGG': 'W', 'GGC': 'G', 'TAC': 'Y', 'TTC': 'F', 'TCG': 'S', 'TTA': 'L', 'TTG': 'L', 'TCC': 'S', 'ACC': 'T', 'TAA': '*', 'GCA': 'A', 'GTA': 'V', 'GCC': 'A', 'GTC': 'V', 'GCG': 'A', 'GTG': 'V', 'GAG': 'E', 'GTT': 'V', 'GCT': 'A', 'GAC': 'D', 'CGT': 'R', 'GAA': 'E', 'TCA': 'S', 'ATG': 'M', 'CGC': 'R'},'flatwormMt':{'CTT': 'L', 'TAG': '*', 'ACA': 'T', 'ACG': 'T', 'ATC': 'I', 'AAC': 'N', 'ATA': 'I', 'AGG': 'S', 'CCT': 'P', 'ACT': 'T', 'AGC': 'S', 'AAG': 'K', 'AGA': 'S', 'CAT': 'H', 'AAT': 'N', 'ATT': 'I', 'CTG': 'L', 'CTA': 'L', 'CTC': 'L', 'CAC': 'H', 'AAA': 'N', 'CCG': 'P', 'AGT': 'S', 'CCA': 'P', 'CAA': 'Q', 'CCC': 'P', 'TAT': 'Y', 'GGT': 'G', 'TGT': 'C', 'CGA': 'R', 'CAG': 'Q', 'TCT': 'S', 'GAT': 'D', 'CGG': 'R', 'TTT': 'F', 'TGC': 'C', 'GGG': 'G', 'TGA': 'W', 'GGA': 'G', 'TGG': 'W', 'GGC': 'G', 'TAC': 'Y', 'TTC': 'F', 'TCG': 'S', 'TTA': 'L', 'TTG': 'L', 'TCC': 'S', 'ACC': 'T', 'TAA': 'Y', 'GCA': 'A', 'GTA': 'V', 'GCC': 'A', 'GTC': 'V', 'GCG': 'A', 'GTG': 'V', 'GAG': 'E', 'GTT': 'V', 'GCT': 'A', 'GAC': 'D', 'CGT': 'R', 'GAA': 'E', 'TCA': 'S', 'ATG': 'M', 'CGC': 'R'},'chlorophyceanMt':{'CTT': 'L', 'TAG': 'L', 'ACA': 'T', 'ACG': 'T', 'ATC': 'I', 'AAC': 'N', 'ATA': 'I', 'AGG': 'R', 'CCT': 'P', 'ACT': 'T', 'AGC': 'S', 'AAG': 'K', 'AGA': 'R', 'CAT': 'H', 'AAT': 'N', 'ATT': 'I', 'CTG': 'L', 'CTA': 'L', 'CTC': 'L', 'CAC': 'H', 'AAA': 'K', 'CCG': 'P', 'AGT': 'S', 'CCA': 'P', 'CAA': 'Q', 'CCC': 'P', 'TAT': 'Y', 'GGT': 'G', 'TGT': 'C', 'CGA': 'R', 'CAG': 'Q', 'TCT': 'S', 'GAT': 'D', 'CGG': 'R', 'TTT': 'F', 'TGC': 'C', 'GGG': 'G', 'TGA': '*', 'GGA': 'G', 'TGG': 'W', 'GGC': 'G', 'TAC': 'Y', 'TTC': 'F', 'TCG': 'S', 'TTA': 'L', 'TTG': 'L', 'TCC': 'S', 'ACC': 'T', 'TAA': '*', 'GCA': 'A', 'GTA': 'V', 'GCC': 'A', 'GTC': 'V', 'GCG': 'A', 'GTG': 'V', 'GAG': 'E', 'GTT': 'V', 'GCT': 'A', 'GAC': 'D', 'CGT': 'R', 'GAA': 'E', 'TCA': 'S', 'ATG': 'M', 'CGC': 'R'},'trematodeMt':{'CTT': 'L', 'TAG': '*', 'ACA': 'T', 'ACG': 'T', 'ATC': 'I', 'AAC': 'N', 'ATA': 'M', 'AGG': 'S', 'CCT': 'P', 'ACT': 'T', 'AGC': 'S', 'AAG': 'K', 'AGA': 'S', 'CAT': 'H', 'AAT': 'N', 'ATT': 'I', 'CTG': 'L', 'CTA': 'L', 'CTC': 'L', 'CAC': 'H', 'AAA': 'N', 'CCG': 'P', 'AGT': 'S', 'CCA': 'P', 'CAA': 'Q', 'CCC': 'P', 'TAT': 'Y', 'GGT': 'G', 'TGT': 'C', 'CGA': 'R', 'CAG': 'Q', 'TCT': 'S', 'GAT': 'D', 'CGG': 'R', 'TTT': 'F', 'TGC': 'C', 'GGG': 'G', 'TGA': 'W', 'GGA': 'G', 'TGG': 'W', 'GGC': 'G', 'TAC': 'Y', 'TTC': 'F', 'TCG': 'S', 'TTA': 'L', 'TTG': 'L', 'TCC': 'S', 'ACC': 'T', 'TAA': '*', 'GCA': 'A', 'GTA': 'V', 'GCC': 'A', 'GTC': 'V', 'GCG': 'A', 'GTG': 'V', 'GAG': 'E', 'GTT': 'V', 'GCT': 'A', 'GAC': 'D', 'CGT': 'R', 'GAA': 'E', 'TCA': 'S', 'ATG': 'M', 'CGC': 'R'},'pterobranchiaMt':{'CTT': 'L', 'TAG': '*', 'ACA': 'T', 'ACG': 'T', 'ATC': 'I', 'AAC': 'N', 'ATA': 'I', 'AGG': 'K', 'CCT': 'P', 'ACT': 'T', 'AGC': 'S', 'AAG': 'K', 'AGA': 'S', 'CAT': 'H', 'AAT': 'N', 'ATT': 'I', 'CTG': 'L', 'CTA': 'L', 'CTC': 'L', 'CAC': 'H', 'AAA': 'K', 'CCG': 'P', 'AGT': 'S', 'CCA': 'P', 'CAA': 'Q', 'CCC': 'P', 'TAT': 'Y', 'GGT': 'G', 'TGT': 'C', 'CGA': 'R', 'CAG': 'Q', 'TCT': 'S', 'GAT': 'D', 'CGG': 'R', 'TTT': 'F', 'TGC': 'C', 'GGG': 'G', 'TGA': 'W', 'GGA': 'G', 'TGG': 'W', 'GGC': 'G', 'TAC': 'Y', 'TTC': 'F', 'TCG': 'S', 'TTA': 'L', 'TTG': 'L', 'TCC': 'S', 'ACC': 'T', 'TAA': '*', 'GCA': 'A', 'GTA': 'V', 'GCC': 'A', 'GTC': 'V', 'GCG': 'A', 'GTG': 'V', 'GAG': 'E', 'GTT': 'V', 'GCT': 'A', 'GAC': 'D', 'CGT': 'R', 'GAA': 'E', 'TCA': 'S', 'ATG': 'M', 'CGC': 'R'}}
    popFileDict = {}
    for line in infile2:
        lineSplit = line.split('\t')
        popFileDict[lineSplit[0]] = lineSplit[1]
    infile2.close()
    infile1 = popFileDict['alignment file']
    outfile = open(popFileDict['outfile'],'w')
    if popFileDict['genetic code'] == '<genetic code>':
        geneticCode = geneticCodes['standard']
    else:
        geneticCode = geneticCodes[popFileDict['genetic code']]
    if popFileDict['alpha'] == '<alpha>':
        alpha = 0.05
    else:
        alpha = popFileDict['alpha']
    popList = []
    if popFileDict['populationKeys'] != '<populationKeys>':
        popKeys = popFileDict['populationKeys'].split(',')
        for key in popKeys:
            popList.append(key)
    else:
        popList = False    
    outGroup = False
    inGroupList = []
    logFile = open(popFileDict['logfile'],'w')
    currTime = time.time() - t1
    logFile.write(str(round(currTime)) + ' seconds -- reading alignmentFile' + '\n')
    alignDict,inputSeqList,outGroup,popDict,inGroupList = seqDictGenerator(infile1,popList)
    logFile.close()
    siteDict = {}
    codonDict = {}
    aaDict = {}
    logFile = open(popFileDict['logfile'],'a')
    currTime = time.time() - t1
    logFile.write(str(round(currTime)) + ' seconds -- making codonDict' + '\n')
    logFile.close()
    proteinFile = open('aaSeqs.fasta','w')
    for seq in inputSeqList:
        currSeq = alignDict[seq]
        if (len(currSeq) % 3) != 0:
            return 'ERROR: Sequence is not divisible by three. Please make sure sequence is protein-coding DNA only'
        currCodons = []
        i = 2
        while i < len(currSeq):
            codon = currSeq[i-2] + currSeq[i-1] + currSeq[i]
            currCodons.append(codon)
            i += 3
        codonDict[seq] = currCodons
        aaSeq = ''
        aaNum = 1
        for codon in currCodons:
            if 'N' in codon or '-' in codon:
                aa = 'X'
            else:
                aa = geneticCode[codon]
                if aa == '*':
                    logFile = open(popFileDict['logfile'],'a')
                    currTime = time.time() - t1
                    logFile.write(str(round(currTime)) + ' seconds -- Sequence ' + seq + ' has a stop codon at amino acid position: ' + str(aaNum) + '\n')
                    logFile.close()
            aaSeq += aa
            aaNum += 1
            aaDict[seq] = aaSeq
            currSites = countSites(currCodons,popFileDict['genetic code'])
            siteDict[seq] = currSites                
        proteinFile.write(seq + '\n' + aaSeq + '\n')    
    proteinFile.close()
    outfile.write('Population Genetic Parameter' + '\t' + 'Overall Calculated Statistic' + '\t' + 'Overall Bootstrap Mean' + '\t' + 'Overall Bootstrap' + str((1-alpha)*100) + ' % CI Low' + '\t' + 'Overall Bootstrap' + str((1-alpha)*100) + ' % CI High' + '\t')
    if popList != False:
        for pop in popList:
            outfile.write('Population "' + pop + '" Calculated Statistic' + '\t' + 'Population "' + pop + '" Bootstrap Mean' + '\t' + 'Population "' + pop + '" ' + str((1-alpha)*100) + ' % CI Low' + '\t' + 'Overall ' + str((1-alpha)*100) + ' % CI High' + '\t')
    outfile.write('\n')
    #popStats output = [numPolymorphisms,numSynPoly,numNonSynPoly,pi,piS,piA,piA_piS,theta,thetaS,thetaA,thetaA_thetaS,tajimasD,tajimasD_A,tajimasD_S]
    logFile = open(popFileDict['logfile'],'a')
    currTime = time.time() - t1
    logFile.write(str(round(currTime)) + ' seconds -- popStats starting for overall pop' + '\n')
    logFile.write(str(inGroupList) + '\n')
    logFile.close()
    overallPopStats = popStats(inGroupList,codonDict,popFileDict['genetic code'],False)
    logFile = open(popFileDict['logfile'],'a')
    currTime = time.time() - t1
    logFile.write(str(round(currTime)) + ' seconds -- popStats done for overall pop' + '\n')
    logFile.close()
    overall_Fst = 'N/A'
    overall_Fst_S = 'N/A'
    overall_Fst_A = 'N/A'
    if outGroup != False:
        #divStats output = [numSubs,numSynSubs,numNonSynSubs,d,dS,dS,dN_dS]
        logFile = open(popFileDict['logfile'],'a')
        currTime = time.time() - t1
        logFile.write(str(round(currTime)) + ' seconds -- divStats starting for overall pop' + '\n')
        logFile.close()
        overallDivStats = divStats(inGroupList,inGroupList,outGroup,codonDict,popFileDict['genetic code'])
        logFile = open(popFileDict['logfile'],'a')
        currTime = time.time() - t1
        logFile.write(str(round(currTime))  + ' seconds -- ' + 'divStats done for overall pop' + '\n')
        logFile.close()
        #popDivStats output = [P_D,Ps_Ds,Pa_Da,NI,alpha]
        overallPopDivStats = popDivStats(overallPopStats,overallDivStats)
    else:
        overallDivStats = ['N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A']
        overallPopDivStats = ['N/A', 'N/A', 'N/A', 'N/A', 'N/A']
    actualDict = {}
    meanDict = {}
    CIDict = {}
    actualDict['overall'] = overallPopStats + overallDivStats + overallPopDivStats
    if popFileDict['bootstrap'] != 'False':
        bootReps = int(popFileDict['bootstrap'])
        overall_numPolymorphisms = []
        overall_numSynPoly = []
        overall_numNonSynPoly = []
        overall_pi = []
        overall_piS = []
        overall_piA = []
        overall_piA_piS = []
        overall_theta = []
        thetaS = []
        overall_thetaA = []
        overall_thetaA_thetaS = []
        overall_tajimasD = []
        overall_tajimasD_A = []
        overall_tajimasD_S = []
        overall_numSubs = []
        overall_numSynSubs = []
        overall_numNonSynSubs = []
        overall_d = []
        overall_dN = []
        overall_dS = []
        overall_dN_dS = []
        overall_P_D = []
        overall_Ps_Ds = []
        overall_Pa_Da = []
        overall_NI = []
        overall_alpha_aa = []
        statList = [overall_numPolymorphisms,overall_numSynPoly, overall_numNonSynPoly,overall_pi,overall_piS,overall_piA,overall_piA_piS,overall_theta,thetaS,overall_thetaA, overall_thetaA_thetaS,overall_tajimasD,overall_tajimasD_A,overall_tajimasD_S,overall_numSubs,overall_numSynSubs,overall_numNonSynSubs,overall_d,overall_dS,overall_dN,overall_dN_dS,overall_P_D,overall_Ps_Ds,overall_Pa_Da,overall_NI,overall_alpha_aa]
        repNum = 0
        percentNum = 0
        logFile = open(popFileDict['logfile'],'a')
        currTime = time.time() - t1
        logFile.write(str(round(currTime)) + ' seconds -- starting bootstrap overall pop' + '\n')
        logFile.close()
        while repNum < bootReps:
            if float(repNum)/bootReps > percentNum*0.10:
                logFile = open(popFileDict['logfile'],'a')
                currTime = time.time() - t1
                logFile.write(str(round(currTime)) + ' seconds -- ' + str(percentNum*10) + "% done bootstrapping overall pop" + '\n')
                logFile.close()
                percentNum += 1
            currSeqs = []
            while len(currSeqs) < len(inGroupList):
                seqNum = random.choice(range(len(inGroupList)))
                currSeqs.append(inGroupList[seqNum])
            currPopStats = popStats(currSeqs,codonDict,popFileDict['genetic code'],True)
            if outGroup != False:
                currDivStats = divStats(currSeqs,inGroupList,outGroup,codonDict,popFileDict['genetic code'])
                currPopDivStats = popDivStats(currPopStats,currDivStats)
            else:
                currDivStats = ['N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A']
                currPopDivStats = ['N/A', 'N/A', 'N/A', 'N/A', 'N/A']
            currStats = currPopStats + currDivStats + currPopDivStats
            m = 0
            for param in statList:
                currValue = currStats[m]
                param.append(currValue)
                m += 1
            repNum += 1
        logFile = open(popFileDict['logfile'],'a')
        currTime = time.time() - t1
        logFile.write(str(round(currTime)) + " seconds -- 100% done bootstrapping overall pop" + '\n')
        logFile.close()
        listOfMeans = []
        listOfCIs = []
        logFile = open(popFileDict['logfile'],'a')
        currTime = time.time() - t1
        logFile.write(str(round(currTime)) + " seconds -- Calculating  means and confidence intervals of bootstrap replicates for overall population" + '\n')
        logFile.close()
        for List in statList:
            parameterMean = 0.0
            numItems = 0
            newList = []
            for item in List:
                if item != 'N/A':
                    parameterMean += item
                    newList.append(item)
                    numItems += 1
            if numItems > 0:
                parameterMean = parameterMean/numItems
            else:
                parameterMean = 'N/A'
            listOfMeans.append(parameterMean)
            lowCI = numItems*(alpha/2.0)
            hiCI = numItems - (numItems*(alpha*2.0))
            newList = sorted(newList)
            if lowCI > 1:
                lowCIValue = newList[int(round(lowCI))]
                hiCIValue = newList[int(round(hiCI))]
            else:
                lowCIValue = 'CI could not be computed'
                hiCIValue = 'CI could not be computed'
            listOfCIs.append((lowCIValue,hiCIValue))
        meanDict['overall'] = listOfMeans
        CIDict['overall'] = listOfCIs
        piDict = {}    #for Fst
    for pop in popList:
        seqList = popDict[pop]
        logFile = open(popFileDict['logfile'],'a')
        currTime = time.time() - t1
        logFile.write(str(round(currTime)) + ' seconds -- starting popStats for population: ' + pop + '\n')
        logFile.close()
        currPopStats = popStats(seqList,codonDict,popFileDict['genetic code'],True)
        if outGroup != False:
            logFile = open(popFileDict['logfile'],'a')
            currTime = time.time() - t1
            logFile.write(str(round(currTime)) + ' seconds -- starting divStats for population: ' + pop + '\n')
            logFile.close()
            currDivStats = divStats(seqList,inGroupList,outGroup,codonDict,popFileDict['genetic code'])
            currPopDivStats = popDivStats(overallPopStats,overallDivStats)
        else:
            currDivStats = ['N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A']
            currPopDivStats = ['N/A', 'N/A', 'N/A', 'N/A', 'N/A']
        actualDict[pop] = currPopStats + currDivStats + currPopDivStats
        if popFileDict['bootstrap'] != 'False':
            numPolymorphisms = []
            numSynPoly = []
            numNonSynPoly = []
            pi = []
            piS = []
            piA = []
            piA_piS = []
            theta = []
            thetaS = []
            thetaA = []
            thetaA_thetaS = []
            tajimasD = []
            tajimasD_A = []
            tajimasD_S = []
            numSubs = []
            numSynSubs = []
            numNonSynSubs = []
            d = []
            dN = []
            dS = []
            dN_dS = []
            P_D = []
            Ps_Ds = []
            Pa_Da = []
            NI = []
            alpha_aa = []
            statList = [numPolymorphisms,numSynPoly, numNonSynPoly,pi,piS,piA,piA_piS,theta,thetaS,thetaA, thetaA_thetaS,tajimasD,tajimasD_A,tajimasD_S,numSubs,numSynSubs,numNonSynSubs,d,dS,dN,dN_dS,P_D,Ps_Ds,Pa_Da,NI,alpha_aa]
            repNum = 0
            logFile = open(popFileDict['logfile'],'a')
            currTime = time.time() - t1
            logFile.write(str(round(currTime)) + ' seconds -- starting bootstrap for population: ' + pop + '\n')
            logFile.close()
            percentNum = 0
            while repNum < bootReps:
                if float(repNum)/bootReps > percentNum*0.10:
                    logFile = open(popFileDict['logfile'],'a')
                    currTime = time.time() - t1
                    logFile.write(str(round(currTime)) + ' seconds -- ' + str(percentNum*10) + "% done bootstrapping pop " + pop + '\n')
                    logFile.close()
                    percentNum += 1
                currSeqs = []
                while len(currSeqs) < len(seqList):
                    seqNum = random.choice(range(len(seqList)))
                    currSeqs.append(inGroupList[seqNum])
                currPopStats = popStats(currSeqs,codonDict,popFileDict['genetic code'],True)
                if outGroup != False:
                    currDivStats = divStats(currSeqs,inGroupList,outGroup,codonDict,popFileDict['genetic code'])
                    currPopDivStats = popDivStats(currPopStats,currDivStats)
                else:
                    currDivStats = ['N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A']
                    currPopDivStats = ['N/A', 'N/A', 'N/A', 'N/A', 'N/A']
                currStats = currPopStats + currDivStats + currPopDivStats
                m = 0
                for param in statList:
                    currValue = currStats[m]
                    param.append(currValue)
                    m += 1
                repNum += 1
            logFile = open(popFileDict['logfile'],'a')
            currTime = time.time() - t1
            logFile.write(str(round(currTime))  + ' seconds -- ' + "100% done bootstrapping pop: " + pop +'\n')
            logFile.close()
            listOfMeans = []
            listOfCIs = []
            logFile = open(popFileDict['logfile'],'a')
            currTime = time.time() - t1
            logFile.write(str(round(currTime))  + ' seconds -- ' +  "Calculating means and confidence intervals of bootstrap replicates for pop " + pop + '\n')
            logFile.close()
            for List in statList:
                parameterMean = 0.0
                numItems = 0
                newList = []
                for item in List:
                    if item != 'N/A':
                        parameterMean += item
                        numItems += 1
                        newList.append(item)
                if numItems > 0:
                    parameterMean = parameterMean/numItems
                else:
                    parameterMean = 'N/A'
                listOfMeans.append(parameterMean)
                lowCI = numItems*(alpha/2.0)
                hiCI = numItems - (numItems*(alpha*2.0))
                newList = sorted(newList)
                if lowCI > 1:
                    lowCIValue = newList[int(round(lowCI))]
                    hiCIValue = newList[int(round(hiCI))]
                else:
                    lowCIValue = 'CI could not be computed'
                    hiCIValue = 'CI could not be computed'
                listOfCIs.append((lowCIValue,hiCIValue))
            meanDict[pop] = listOfMeans
            CIDict[pop] = listOfCIs
    if popFileDict['bootstrap'] != 'False':       
        p = 0
        numParam = len(actualDict['overall'])
        paramList = ['numPolymorphisms','numSynPoly','numNonSynPoly','pi','piS','piA','piA_piS','theta','thetaS','thetaA','thetaA_thetaS','tajimasD','tajimasD_A','tajimasD_S','numSubs','numSynSubs','numNonSynSubs','d','dS','dS','dN_dS','P_D','Ps_Ds','Pa_Da','NI','alpha']
        logFile = open(popFileDict['logfile'],'a')
        currTime = time.time() - t1
        logFile.write(str(round(currTime))  + ' seconds -- ' +  'writing to outfile' + '\n')
        logFile.close()
        while p < numParam:
            overallActualList = actualDict['overall']
            overallMeanList = meanDict['overall']
            overallCIList = CIDict['overall']
            outfile.write(paramList[p] + '\t' + str(overallActualList[p]) + '\t' + str(overallMeanList[p]) + '\t')
            currCIs = overallCIList[p]
            outfile.write(str(currCIs[0]) + '\t' + str(currCIs[1]))
            for pop in popList:
                currActualList = actualDict[pop]
                currMeanList = meanDict[pop]
                currCIList = CIDict[pop]
                outfile.write('\t' + str(currActualList[p]) + '\t' + str(currMeanList[p]) + '\t')
                currCIs = currCIList[p]
                outfile.write(str(currCIs[0]) + '\t' + str(currCIs[1]))
            outfile.write('\n')
            p += 1
    else:
        p = 0
        numParam = len(actualDict['overall'])
        paramList = ['numPolymorphisms','numSynPoly','numNonSynPoly','pi','piS','piA','piA_piS','theta','thetaS','thetaA','thetaA_thetaS','tajimasD','tajimasD_A','tajimasD_S','numSubs','numSynSubs','numNonSynSubs','d','dS','dN','dN_dS','P_D','Ps_Ds','Pa_Da','NI','alpha']
        logFile = open(popFileDict['logfile'],'a')
        currTime = time.time() - t1
        logFile.write(str(round(currTime))  + ' seconds -- ' +  'writing to outfile' + '\n')
        logFile.close()
        while p < numParam:
            overallActualList = actualDict['overall']
            outfile.write(paramList[p] + '\t' + str(overallActualList[p]) + '\t\t\t') 
            for pop in popList:
                currActualList = actualDict[pop]
                outfile.write('\t' + str(currActualList[p]) + '\t\t\t')
            outfile.write('\n')
            p += 1
    outfile.close()
    
def seqDictGenerator(fasta,popList):
    infile = open(fasta,'r')
    scaffoldDict = {}
    scaffoldList = []
    seqName = ''
    currSeq = ''
    inGroupList = []
    popDict = {}
    outGroup = False
    if popList != False:
        for pop in popList:
            popDict[pop] = []
    for line in infile:
        if line[0] == '>':
            if seqName != '':
                scaffoldDict[seqName] = currSeq
            seqName = line
            while seqName[-1] == '\n' or seqName[-1] == '\t' or seqName[-1] == '\r':
                seqName = seqName[0:-1]
            scaffoldList.append(seqName)
            currSeq = ''
            if seqName[-1] == '+':
                outGroup = seqName
            else:
                inGroupList.append(seqName)
            if popList != False:
                for pop in popList:
                    if pop in seqName:
                        popDict[pop] = popDict[pop] + [seqName]
        else:
            currSeq += line
            while currSeq[-1] == '\n' or currSeq[-1] == '\t' or currSeq[-1] == '\r':
                currSeq = currSeq[0:-1]
    scaffoldDict[seqName] = currSeq 
    return scaffoldDict, scaffoldList,outGroup,popDict,inGroupList
    
def popDivStats(popStats,divStats):
    if divStats[0] > 0:
        P_D = float(popStats[0])/float(divStats[0])
    else:
        P_D = 'N/A'
    if divStats[1] > 0:
        Ps_Ds = float(popStats[1])/float(divStats[1])
    else:
        Ps_Ds = 'N/A'
    if divStats[2] > 0:
        Pa_Da = float(popStats[2])/float(divStats[2])
    else:
        Pa_Da = 'N/A'
    if popStats[1] > 0 and divStats[2] > 0:
        NI = (float(popStats[2])*divStats[1])/(popStats[1]*divStats[2])
        alpha = (1 - (float(popStats[2])*divStats[1])/(popStats[1]*divStats[2]))
    else:
        NI = 'N/A'
        alpha = 'N/A'
    return [P_D,Ps_Ds,Pa_Da,NI,alpha]    

def divStats(seqList,seqList2,outgroupName,codonDict,code):
    #Only considers codons with 2 or fewer changes between them and 2 or fewer alleles at the codon of interest. For codons with 2 changes, pathway with fewest number of nonsynonymous changes is assumed. Sites with missing data are partially ignored by removing that sample from the codon-by-codon analysis. Codons with missing data are assumed to have 0.71875 synonymous sites and 2.28125 nonsynonymous sites.
    geneticCodes = {'standard':{"TTT":"F",	"TTC":"F",	"TTA":"L",	"TTG":"L",	"TCT":"S",	"TCC":"S",	"TCA":"S",	"TCG":"S",	"TAT":"Y",	"TAC":"Y",	"TAA":"*",	"TAG":"*",	"TGT":"C",	"TGC":"C",	"TGA":"*",	"TGG":"W",	"CTT":"L",	"CTC":"L",	"CTA":"L",	"CTG":"L",	"CCT":"P",	"CCC":"P",	"CCA":"P",	"CCG":"P",	"CAT":"H",	"CAC":"H",	"CAA":"Q",	"CAG":"Q",	"CGT":"R",	"CGC":"R",	"CGA":"R",	"CGG":"R",	"ATT":"I",	"ATC":"I",	"ATA":"I",	"ATG":"M",	"ACT":"T",	"ACC":"T",	"ACA":"T",	"ACG":"T",	"AAT":"N",	"AAC":"N",	"AAA":"K",	"AAG":"K",	"AGT":"S",	"AGC":"S",	"AGA":"R",	"AGG":"R",	"GTT":"V",	"GTC":"V",	"GTA":"V",	"GTG":"V",	"GCT":"A",	"GCC":"A",	"GCA":"A",	"GCG":"A",	"GAT":"D",	"GAC":"D",	"GAA":"E",	"GAG":"E",	"GGT":"G",	"GGC":"G",	"GGA":"G",	"GGG":"G"},'invertebrateMt':{'CTT': 'L', 'TAG': '*', 'ACA': 'T', 'ACG': 'T', 'ATC': 'I', 'AAC': 'N', 'ATA': 'M', 'AGG': 'S', 'CCT': 'P', 'ACT': 'T', 'AGC': 'S', 'AAG': 'K', 'AGA': 'S', 'CAT': 'H', 'AAT': 'N', 'ATT': 'I', 'CTG': 'L', 'CTA': 'L', 'CTC': 'L', 'CAC': 'H', 'AAA': 'K', 'CCG': 'P', 'AGT': 'S', 'CCA': 'P', 'CAA': 'Q', 'CCC': 'P', 'TAT': 'Y', 'GGT': 'G', 'TGT': 'C', 'CGA': 'R', 'CAG': 'Q', 'TCT': 'S', 'GAT': 'D', 'CGG': 'R', 'TTT': 'F', 'TGC': 'C', 'GGG': 'G', 'TGA': 'W', 'GGA': 'G', 'TGG': 'W', 'GGC': 'G', 'TAC': 'Y', 'TTC': 'F', 'TCG': 'S', 'TTA': 'L', 'TTG': 'L', 'TCC': 'S', 'ACC': 'T', 'TAA': '*', 'GCA': 'A', 'GTA': 'V', 'GCC': 'A', 'GTC': 'V', 'GCG': 'A', 'GTG': 'V', 'GAG': 'E', 'GTT': 'V', 'GCT': 'A', 'GAC': 'D', 'CGT': 'R', 'GAA': 'E', 'TCA': 'S', 'ATG': 'M', 'CGC': 'R'},'vertebrateMt':{'CTT': 'L', 'TAG': '*', 'ACA': 'T', 'ACG': 'T', 'ATC': 'I', 'AAC': 'N', 'ATA': 'M', 'AGG': '*', 'CCT': 'P', 'ACT': 'T', 'AGC': 'S', 'AAG': 'K', 'AGA': '*', 'CAT': 'H', 'AAT': 'N', 'ATT': 'I', 'CTG': 'L', 'CTA': 'L', 'CTC': 'L', 'CAC': 'H', 'AAA': 'K', 'CCG': 'P', 'AGT': 'S', 'CCA': 'P', 'CAA': 'Q', 'CCC': 'P', 'TAT': 'Y', 'GGT': 'G', 'TGT': 'C', 'CGA': 'R', 'CAG': 'Q', 'TCT': 'S', 'GAT': 'D', 'CGG': 'R', 'TTT': 'F', 'TGC': 'C', 'GGG': 'G', 'TGA': 'W', 'GGA': 'G', 'TGG': 'W', 'GGC': 'G', 'TAC': 'Y', 'TTC': 'F', 'TCG': 'S', 'TTA': 'L', 'TTG': 'L', 'TCC': 'S', 'ACC': 'T', 'TAA': '*', 'GCA': 'A', 'GTA': 'V', 'GCC': 'A', 'GTC': 'V', 'GCG': 'A', 'GTG': 'V', 'GAG': 'E', 'GTT': 'V', 'GCT': 'A', 'GAC': 'D', 'CGT': 'R', 'GAA': 'E', 'TCA': 'S', 'ATG': 'M', 'CGC': 'R'}, 'yeastMt':{'CTT': 'T', 'TAG': '*', 'ACA': 'T', 'ACG': 'T', 'ATC': 'I', 'AAC': 'N', 'ATA': 'M', 'AGG': 'R', 'CCT': 'P', 'ACT': 'T', 'AGC': 'S', 'AAG': 'K', 'AGA': 'R', 'CAT': 'H', 'AAT': 'N', 'ATT': 'I', 'CTG': 'T', 'CTA': 'T', 'CTC': 'T', 'CAC': 'H', 'AAA': 'K', 'CCG': 'P', 'AGT': 'S', 'CCA': 'P', 'CAA': 'Q', 'CCC': 'P', 'TAT': 'Y', 'GGT': 'G', 'TGT': 'C', 'CGA': 'R', 'CAG': 'Q', 'TCT': 'S', 'GAT': 'D', 'CGG': 'R', 'TTT': 'F', 'TGC': 'C', 'GGG': 'G', 'TGA': 'W', 'GGA': 'G', 'TGG': 'W', 'GGC': 'G', 'TAC': 'Y', 'TTC': 'F', 'TCG': 'S', 'TTA': 'L', 'TTG': 'L', 'TCC': 'S', 'ACC': 'T', 'TAA': '*', 'GCA': 'A', 'GTA': 'V', 'GCC': 'A', 'GTC': 'V', 'GCG': 'A', 'GTG': 'V', 'GAG': 'E', 'GTT': 'V', 'GCT': 'A', 'GAC': 'D', 'CGT': 'R', 'GAA': 'E', 'TCA': 'S', 'ATG': 'M', 'CGC': 'R'}, 'coelenterateMt':{'CTT': 'L', 'TAG': '*', 'ACA': 'T', 'ACG': 'T', 'ATC': 'I', 'AAC': 'N', 'ATA': 'I', 'AGG': 'R', 'CCT': 'P', 'ACT': 'T', 'AGC': 'S', 'AAG': 'K', 'AGA': 'R', 'CAT': 'H', 'AAT': 'N', 'ATT': 'I', 'CTG': 'L', 'CTA': 'L', 'CTC': 'L', 'CAC': 'H', 'AAA': 'K', 'CCG': 'P', 'AGT': 'S', 'CCA': 'P', 'CAA': 'Q', 'CCC': 'P', 'TAT': 'Y', 'GGT': 'G', 'TGT': 'C', 'CGA': 'R', 'CAG': 'Q', 'TCT': 'S', 'GAT': 'D', 'CGG': 'R', 'TTT': 'F', 'TGC': 'C', 'GGG': 'G', 'TGA': 'W', 'GGA': 'G', 'TGG': 'W', 'GGC': 'G', 'TAC': 'Y', 'TTC': 'F', 'TCG': 'S', 'TTA': 'L', 'TTG': 'L', 'TCC': 'S', 'ACC': 'T', 'TAA': '*', 'GCA': 'A', 'GTA': 'V', 'GCC': 'A', 'GTC': 'V', 'GCG': 'A', 'GTG': 'V', 'GAG': 'E', 'GTT': 'V', 'GCT': 'A', 'GAC': 'D', 'CGT': 'R', 'GAA': 'E', 'TCA': 'S', 'ATG': 'M', 'CGC': 'R'},'ciliateNuc':{'CTT': 'L', 'TAG': 'Q', 'ACA': 'T', 'ACG': 'T', 'ATC': 'I', 'AAC': 'N', 'ATA': 'I', 'AGG': 'R', 'CCT': 'P', 'ACT': 'T', 'AGC': 'S', 'AAG': 'K', 'AGA': 'R', 'CAT': 'H', 'AAT': 'N', 'ATT': 'I', 'CTG': 'L', 'CTA': 'L', 'CTC': 'L', 'CAC': 'H', 'AAA': 'K', 'CCG': 'P', 'AGT': 'S', 'CCA': 'P', 'CAA': 'Q', 'CCC': 'P', 'TAT': 'Y', 'GGT': 'G', 'TGT': 'C', 'CGA': 'R', 'CAG': 'Q', 'TCT': 'S', 'GAT': 'D', 'CGG': 'R', 'TTT': 'F', 'TGC': 'C', 'GGG': 'G', 'TGA': '*', 'GGA': 'G', 'TGG': 'W', 'GGC': 'G', 'TAC': 'Y', 'TTC': 'F', 'TCG': 'S', 'TTA': 'L', 'TTG': 'L', 'TCC': 'S', 'ACC': 'T', 'TAA': 'Q', 'GCA': 'A', 'GTA': 'V', 'GCC': 'A', 'GTC': 'V', 'GCG': 'A', 'GTG': 'V', 'GAG': 'E', 'GTT': 'V', 'GCT': 'A', 'GAC': 'D', 'CGT': 'R', 'GAA': 'E', 'TCA': 'S', 'ATG': 'M', 'CGC': 'R'},'echinodermMt':{'CTT': 'L', 'TAG': '*', 'ACA': 'T', 'ACG': 'T', 'ATC': 'I', 'AAC': 'N', 'ATA': 'I', 'AGG': 'S', 'CCT': 'P', 'ACT': 'T', 'AGC': 'S', 'AAG': 'K', 'AGA': 'S', 'CAT': 'H', 'AAT': 'N', 'ATT': 'I', 'CTG': 'L', 'CTA': 'L', 'CTC': 'L', 'CAC': 'H', 'AAA': 'N', 'CCG': 'P', 'AGT': 'S', 'CCA': 'P', 'CAA': 'Q', 'CCC': 'P', 'TAT': 'Y', 'GGT': 'G', 'TGT': 'C', 'CGA': 'R', 'CAG': 'Q', 'TCT': 'S', 'GAT': 'D', 'CGG': 'R', 'TTT': 'F', 'TGC': 'C', 'GGG': 'G', 'TGA': 'W', 'GGA': 'G', 'TGG': 'W', 'GGC': 'G', 'TAC': 'Y', 'TTC': 'F', 'TCG': 'S', 'TTA': 'L', 'TTG': 'L', 'TCC': 'S', 'ACC': 'T', 'TAA': '*', 'GCA': 'A', 'GTA': 'V', 'GCC': 'A', 'GTC': 'V', 'GCG': 'A', 'GTG': 'V', 'GAG': 'E', 'GTT': 'V', 'GCT': 'A', 'GAC': 'D', 'CGT': 'R', 'GAA': 'E', 'TCA': 'S', 'ATG': 'M', 'CGC': 'R'}, 'euplotidNuc':{'CTT': 'L', 'TAG': '*', 'ACA': 'T', 'ACG': 'T', 'ATC': 'I', 'AAC': 'N', 'ATA': 'I', 'AGG': 'R', 'CCT': 'P', 'ACT': 'T', 'AGC': 'S', 'AAG': 'K', 'AGA': 'R', 'CAT': 'H', 'AAT': 'N', 'ATT': 'I', 'CTG': 'L', 'CTA': 'L', 'CTC': 'L', 'CAC': 'H', 'AAA': 'K', 'CCG': 'P', 'AGT': 'S', 'CCA': 'P', 'CAA': 'Q', 'CCC': 'P', 'TAT': 'Y', 'GGT': 'G', 'TGT': 'C', 'CGA': 'R', 'CAG': 'Q', 'TCT': 'S', 'GAT': 'D', 'CGG': 'R', 'TTT': 'F', 'TGC': 'C', 'GGG': 'G', 'TGA': 'C', 'GGA': 'G', 'TGG': 'W', 'GGC': 'G', 'TAC': 'Y', 'TTC': 'F', 'TCG': 'S', 'TTA': 'L', 'TTG': 'L', 'TCC': 'S', 'ACC': 'T', 'TAA': '*', 'GCA': 'A', 'GTA': 'V', 'GCC': 'A', 'GTC': 'V', 'GCG': 'A', 'GTG': 'V', 'GAG': 'E', 'GTT': 'V', 'GCT': 'A', 'GAC': 'D', 'CGT': 'R', 'GAA': 'E', 'TCA': 'S', 'ATG': 'M', 'CGC': 'R'}, 'bacterial':{'CTT': 'L', 'TAG': '*', 'ACA': 'T', 'ACG': 'T', 'ATC': 'I', 'AAC': 'N', 'ATA': 'I', 'AGG': 'R', 'CCT': 'P', 'ACT': 'T', 'AGC': 'S', 'AAG': 'K', 'AGA': 'R', 'CAT': 'H', 'AAT': 'N', 'ATT': 'I', 'CTG': 'L', 'CTA': 'L', 'CTC': 'L', 'CAC': 'H', 'AAA': 'K', 'CCG': 'P', 'AGT': 'S', 'CCA': 'P', 'CAA': 'Q', 'CCC': 'P', 'TAT': 'Y', 'GGT': 'G', 'TGT': 'C', 'CGA': 'R', 'CAG': 'Q', 'TCT': 'S', 'GAT': 'D', 'CGG': 'R', 'TTT': 'F', 'TGC': 'C', 'GGG': 'G', 'TGA': '*', 'GGA': 'G', 'TGG': 'W', 'GGC': 'G', 'TAC': 'Y', 'TTC': 'F', 'TCG': 'S', 'TTA': 'L', 'TTG': 'L', 'TCC': 'S', 'ACC': 'T', 'TAA': '*', 'GCA': 'A', 'GTA': 'V', 'GCC': 'A', 'GTC': 'V', 'GCG': 'A', 'GTG': 'V', 'GAG': 'E', 'GTT': 'V', 'GCT': 'A', 'GAC': 'D', 'CGT': 'R', 'GAA': 'E', 'TCA': 'S', 'ATG': 'M', 'CGC': 'R'},'yeastNuc':{'CTT': 'L', 'TAG': '*', 'ACA': 'T', 'ACG': 'T', 'ATC': 'I', 'AAC': 'N', 'ATA': 'I', 'AGG': 'R', 'CCT': 'P', 'ACT': 'T', 'AGC': 'S', 'AAG': 'K', 'AGA': 'R', 'CAT': 'H', 'AAT': 'N', 'ATT': 'I', 'CTG': 'S', 'CTA': 'L', 'CTC': 'L', 'CAC': 'H', 'AAA': 'K', 'CCG': 'P', 'AGT': 'S', 'CCA': 'P', 'CAA': 'Q', 'CCC': 'P', 'TAT': 'Y', 'GGT': 'G', 'TGT': 'C', 'CGA': 'R', 'CAG': 'Q', 'TCT': 'S', 'GAT': 'D', 'CGG': 'R', 'TTT': 'F', 'TGC': 'C', 'GGG': 'G', 'TGA': '*', 'GGA': 'G', 'TGG': 'W', 'GGC': 'G', 'TAC': 'Y', 'TTC': 'F', 'TCG': 'S', 'TTA': 'L', 'TTG': 'L', 'TCC': 'S', 'ACC': 'T', 'TAA': '*', 'GCA': 'A', 'GTA': 'V', 'GCC': 'A', 'GTC': 'V', 'GCG': 'A', 'GTG': 'V', 'GAG': 'E', 'GTT': 'V', 'GCT': 'A', 'GAC': 'D', 'CGT': 'R', 'GAA': 'E', 'TCA': 'S', 'ATG': 'M', 'CGC': 'R'}, 'ascidianMt':{'CTT': 'L', 'TAG': '*', 'ACA': 'T', 'ACG': 'T', 'ATC': 'I', 'AAC': 'N', 'ATA': 'M', 'AGG': 'G', 'CCT': 'P', 'ACT': 'T', 'AGC': 'S', 'AAG': 'K', 'AGA': 'G', 'CAT': 'H', 'AAT': 'N', 'ATT': 'I', 'CTG': 'L', 'CTA': 'L', 'CTC': 'L', 'CAC': 'H', 'AAA': 'K', 'CCG': 'P', 'AGT': 'S', 'CCA': 'P', 'CAA': 'Q', 'CCC': 'P', 'TAT': 'Y', 'GGT': 'G', 'TGT': 'C', 'CGA': 'R', 'CAG': 'Q', 'TCT': 'S', 'GAT': 'D', 'CGG': 'R', 'TTT': 'F', 'TGC': 'C', 'GGG': 'G', 'TGA': 'W', 'GGA': 'G', 'TGG': 'W', 'GGC': 'G', 'TAC': 'Y', 'TTC': 'F', 'TCG': 'S', 'TTA': 'L', 'TTG': 'L', 'TCC': 'S', 'ACC': 'T', 'TAA': '*', 'GCA': 'A', 'GTA': 'V', 'GCC': 'A', 'GTC': 'V', 'GCG': 'A', 'GTG': 'V', 'GAG': 'E', 'GTT': 'V', 'GCT': 'A', 'GAC': 'D', 'CGT': 'R', 'GAA': 'E', 'TCA': 'S', 'ATG': 'M', 'CGC': 'R'},'flatwormMt':{'CTT': 'L', 'TAG': '*', 'ACA': 'T', 'ACG': 'T', 'ATC': 'I', 'AAC': 'N', 'ATA': 'I', 'AGG': 'S', 'CCT': 'P', 'ACT': 'T', 'AGC': 'S', 'AAG': 'K', 'AGA': 'S', 'CAT': 'H', 'AAT': 'N', 'ATT': 'I', 'CTG': 'L', 'CTA': 'L', 'CTC': 'L', 'CAC': 'H', 'AAA': 'N', 'CCG': 'P', 'AGT': 'S', 'CCA': 'P', 'CAA': 'Q', 'CCC': 'P', 'TAT': 'Y', 'GGT': 'G', 'TGT': 'C', 'CGA': 'R', 'CAG': 'Q', 'TCT': 'S', 'GAT': 'D', 'CGG': 'R', 'TTT': 'F', 'TGC': 'C', 'GGG': 'G', 'TGA': 'W', 'GGA': 'G', 'TGG': 'W', 'GGC': 'G', 'TAC': 'Y', 'TTC': 'F', 'TCG': 'S', 'TTA': 'L', 'TTG': 'L', 'TCC': 'S', 'ACC': 'T', 'TAA': 'Y', 'GCA': 'A', 'GTA': 'V', 'GCC': 'A', 'GTC': 'V', 'GCG': 'A', 'GTG': 'V', 'GAG': 'E', 'GTT': 'V', 'GCT': 'A', 'GAC': 'D', 'CGT': 'R', 'GAA': 'E', 'TCA': 'S', 'ATG': 'M', 'CGC': 'R'},'chlorophyceanMt':{'CTT': 'L', 'TAG': 'L', 'ACA': 'T', 'ACG': 'T', 'ATC': 'I', 'AAC': 'N', 'ATA': 'I', 'AGG': 'R', 'CCT': 'P', 'ACT': 'T', 'AGC': 'S', 'AAG': 'K', 'AGA': 'R', 'CAT': 'H', 'AAT': 'N', 'ATT': 'I', 'CTG': 'L', 'CTA': 'L', 'CTC': 'L', 'CAC': 'H', 'AAA': 'K', 'CCG': 'P', 'AGT': 'S', 'CCA': 'P', 'CAA': 'Q', 'CCC': 'P', 'TAT': 'Y', 'GGT': 'G', 'TGT': 'C', 'CGA': 'R', 'CAG': 'Q', 'TCT': 'S', 'GAT': 'D', 'CGG': 'R', 'TTT': 'F', 'TGC': 'C', 'GGG': 'G', 'TGA': '*', 'GGA': 'G', 'TGG': 'W', 'GGC': 'G', 'TAC': 'Y', 'TTC': 'F', 'TCG': 'S', 'TTA': 'L', 'TTG': 'L', 'TCC': 'S', 'ACC': 'T', 'TAA': '*', 'GCA': 'A', 'GTA': 'V', 'GCC': 'A', 'GTC': 'V', 'GCG': 'A', 'GTG': 'V', 'GAG': 'E', 'GTT': 'V', 'GCT': 'A', 'GAC': 'D', 'CGT': 'R', 'GAA': 'E', 'TCA': 'S', 'ATG': 'M', 'CGC': 'R'},'trematodeMt':{'CTT': 'L', 'TAG': '*', 'ACA': 'T', 'ACG': 'T', 'ATC': 'I', 'AAC': 'N', 'ATA': 'M', 'AGG': 'S', 'CCT': 'P', 'ACT': 'T', 'AGC': 'S', 'AAG': 'K', 'AGA': 'S', 'CAT': 'H', 'AAT': 'N', 'ATT': 'I', 'CTG': 'L', 'CTA': 'L', 'CTC': 'L', 'CAC': 'H', 'AAA': 'N', 'CCG': 'P', 'AGT': 'S', 'CCA': 'P', 'CAA': 'Q', 'CCC': 'P', 'TAT': 'Y', 'GGT': 'G', 'TGT': 'C', 'CGA': 'R', 'CAG': 'Q', 'TCT': 'S', 'GAT': 'D', 'CGG': 'R', 'TTT': 'F', 'TGC': 'C', 'GGG': 'G', 'TGA': 'W', 'GGA': 'G', 'TGG': 'W', 'GGC': 'G', 'TAC': 'Y', 'TTC': 'F', 'TCG': 'S', 'TTA': 'L', 'TTG': 'L', 'TCC': 'S', 'ACC': 'T', 'TAA': '*', 'GCA': 'A', 'GTA': 'V', 'GCC': 'A', 'GTC': 'V', 'GCG': 'A', 'GTG': 'V', 'GAG': 'E', 'GTT': 'V', 'GCT': 'A', 'GAC': 'D', 'CGT': 'R', 'GAA': 'E', 'TCA': 'S', 'ATG': 'M', 'CGC': 'R'},'pterobranchiaMt':{'CTT': 'L', 'TAG': '*', 'ACA': 'T', 'ACG': 'T', 'ATC': 'I', 'AAC': 'N', 'ATA': 'I', 'AGG': 'K', 'CCT': 'P', 'ACT': 'T', 'AGC': 'S', 'AAG': 'K', 'AGA': 'S', 'CAT': 'H', 'AAT': 'N', 'ATT': 'I', 'CTG': 'L', 'CTA': 'L', 'CTC': 'L', 'CAC': 'H', 'AAA': 'K', 'CCG': 'P', 'AGT': 'S', 'CCA': 'P', 'CAA': 'Q', 'CCC': 'P', 'TAT': 'Y', 'GGT': 'G', 'TGT': 'C', 'CGA': 'R', 'CAG': 'Q', 'TCT': 'S', 'GAT': 'D', 'CGG': 'R', 'TTT': 'F', 'TGC': 'C', 'GGG': 'G', 'TGA': 'W', 'GGA': 'G', 'TGG': 'W', 'GGC': 'G', 'TAC': 'Y', 'TTC': 'F', 'TCG': 'S', 'TTA': 'L', 'TTG': 'L', 'TCC': 'S', 'ACC': 'T', 'TAA': '*', 'GCA': 'A', 'GTA': 'V', 'GCC': 'A', 'GTC': 'V', 'GCG': 'A', 'GTG': 'V', 'GAG': 'E', 'GTT': 'V', 'GCT': 'A', 'GAC': 'D', 'CGT': 'R', 'GAA': 'E', 'TCA': 'S', 'ATG': 'M', 'CGC': 'R'}}
    geneticCode = geneticCodes[code]
    N = len(seqList2)
    if N > 1:
        wholeCodons = []
        codonsWithPolymorphisms = []
        mixedCodons = {}
        currSeqs = []
        for seq in seqList2:
            currSeq = codonDict[seq]
            currSeqs.append(currSeq)
        seqLength = len(currSeqs[0])
        i = 0
        while i < seqLength:
            currSite = []
            for sample in currSeqs:
                currSite.append(sample[i])
            x = 0
            xs = []
            for j in range(len(currSite)):
                if 'N' in currSite[j] or '-' in currSite[j]:
                    xs.append(j-x)
                    x += 1
            for item in xs:
                del currSite[item]
            xs = []
            if len(currSite) > 1:
                compareCodon = currSite[0]
                currentAlleles = [compareCodon]
                for codon in currSite[1:]:
                    if compareCodon != codon:
                        if codon not in currentAlleles:
                            currentAlleles.append(codon)
                if len(currentAlleles) == 1:
                    wholeCodons.append(i)
                elif len(currentAlleles) > 1:
                    k = 0
                    samePos = []
                    while k < 3:
                        compareSite = compareCodon[k]
                        currentNucAlleles = [compareSite]
                        for allele in currentAlleles[1:]:
                            if allele[k] != compareSite:
                                if allele[k] not in currentNucAlleles:
                                    currentNucAlleles.append(allele[k])
                        if len(currentNucAlleles) == 1:
                            samePos.append(k)
                        k += 1
                    codonsWithPolymorphisms.append(i)
                    mixedCodons[i] = [currentAlleles,samePos]
            i += 1                
        numSubs = 0
        numSynSubs = 0
        numNonSynSubs = 0
        outGroupCodons = codonDict[outgroupName]
        outGroupSites = countSites(outGroupCodons,code)
        outGroupSynSites = outGroupSites[0]
        outGroupNonSynSites = outGroupSites[1]
        fewestNs = len(outGroupCodons)*3
        seqNum = 0
        for seq in currSeqs:
            currNumNs = 0
            for codon in seq:
                for nuc in codon:
                    if nuc == 'N' or nuc == '-':
                        currNumNs += 1
            if currNumNs < fewestNs:
                fewestNs = currNumNs
                compareSeqNum = seqNum
            seqNum += 1   
        inGroupCodons = currSeqs[compareSeqNum]        
        for codon in wholeCodons:
            inGroupCodon = inGroupCodons[codon]
            outGroupCodon = outGroupCodons[codon]
            if (inGroupCodon != outGroupCodon) and ('N' not in inGroupCodon) and ('N' not in outGroupCodon) and ('-' not in inGroupCodon) and ('-' not in outGroupCodon):
                inGroupAA = geneticCode[inGroupCodon]
                outGroupAA = geneticCode[outGroupCodon]
                numDiff = 0
                site1 = [inGroupCodon[0],outGroupCodon[0]]
                site2 = [inGroupCodon[1],outGroupCodon[1]]
                site3 = [inGroupCodon[2],outGroupCodon[2]]
                if site1[0] != site1[1]:
                    numDiff += 1
                if site2[0] != site2[1]:
                    numDiff += 1
                if site3[0] != site3[1]:
                    numDiff += 1
                if numDiff < 2:
                    numSubs += 1
                    if inGroupAA == outGroupAA:
                        numSynSubs += 1
                    else:
                        numNonSynSubs += 1
                elif numDiff == 2:
                    numSubs += 2
                    if site1[0] != site1[1]:
                        if site2[0] != site2[1]:
                            int1 = site1[1] + inGroupCodon[1:]
                            int2 = site1[0] + outGroupCodon[1:]
                        else:
                            int1 = site1[1] + inGroupCodon[1:]
                            int2 = site1[0] + outGroupCodon[1:]    
                    elif site2[0] != site2[1]:
                        int1 = site1[0] + site2[1] + inGroupCodon[2]
                        int2 = site1[0] + site2[0] + outGroupCodon[2]
                    numSynDiff_a = 0
                    numNonSynDiff_a = 0
                    int1AA = geneticCode[int1]
                    int2AA = geneticCode[int2]
                    if int1AA != inGroupAA:
                        numNonSynDiff_a += 1
                        if int1AA != outGroupAA:
                            numNonSynDiff_a += 1
                        else:
                            numSynDiff_a += 1
                    else:
                        numSynDiff_a += 1
                    numSynDiff_b = 0
                    numNonSynDiff_b = 0
                    if int2AA != inGroupAA:
                        numNonSynDiff_b += 1
                        if int2AA != outGroupAA:
                            numNonSynDiff_b += 1
                        else:
                            numSynDiff_b += 1
                    else:
                        numSynDiff_b += 1
                    if int2AA != '*' and int1AA != '*':
                        if numSynDiff_a > numSynDiff_b:
                            numSynDiff = numSynDiff_a
                            numNonSynDiff = numNonSynDiff_a
                        elif numSynDiff_b > numSynDiff_a:
                            numSynDiff = numSynDiff_b
                            numNonSynDiff = numNonSynDiff_b
                        else:
                            numSynDiff = numSynDiff_a
                            numNonSynDiff = numNonSynDiff_a
                    elif int1AA == '*':
                        if int2AA == '*':
                            numSynDiff = numSynDiff_a
                            numNonSynDiff = numNonSynDiff_a
                        else:
                            numSynDiff = numSynDiff_b
                            numNonSynDiff = numNonSynDiff_b
                    else:
                        numSynDiff = numSynDiff_a
                        numNonSynDiff = numNonSynDiff_a
                    numSynSubs += numSynDiff
                    numNonSynSubs += numNonSynDiff
        for codon in codonsWithPolymorphisms:
            mixedAlleles = mixedCodons[codon]
            inGroupAlleles = mixedAlleles[0]
            inGroupAA = []
            for inGroupCodon in inGroupAlleles:
                if 'N' not in inGroupCodon  or '-' not in inGroupCodon:
                    currAA = geneticCode[inGroupCodon]
                    if currAA not in inGroupAA:
                        inGroupAA.append(currAA)
                else:
                    currAA = 'X'
            samePos = mixedAlleles[1]
            outGroupCodon = outGroupCodons[codon]
            if 'N' not in outGroupCodon and '-' not in outGroupCodon:
                outGroupAA = geneticCode[outGroupCodon]
                if len(inGroupAlleles) == 2:
                    k = 0
                    while k < 3:
                        if k in samePos:
                            inGroupCodon = inGroupAlleles[0]
                            if outGroupCodon[k] != inGroupCodon[k]:
                                if outGroupAA != geneticCode[inGroupCodon]:
                                    numNonSynSubs += 1
                                else:
                                    numSynSubs += 1
                        else:
                            subs = True
                            l = 0
                            while subs == True and l < len(inGroupAlleles):
                                for allele in inGroupAlleles:
                                    if outGroupCodon[k] == allele[k]:
                                        subs = False
                                    l += 1
                            if subs == True:
                                numSubs += 1
                                aaSub = True
                                m = 0
                                while aaSub == True and m < len(inGroupAA):
                                    for aa in inGroupAA:
                                        if outGroupAA == aa:
                                            aaSub = False
                                        m += 1
                                if aaSub == True:
                                    numNonSynSubs += 1
                                else:
                                    numSynSubs += 1
                        k += 1  
                else:
                    outGroupAA = 'X'       
    else:
        numSubs = 0
        numSynSubs = 0
        numNonSynSubs = 0
        outGroupCodons = codonDict[outgroupName]
        outGroupSites = countSites(outGroupCodons,code)
        outGroupSynSites = outGroupSites[0]
        outGroupNonSynSites = outGroupSites[1]
        for codon in range(len(inGroupCodons)):
            inGroupCodon = inGroupCodons[codon]
            outGroupCodon = outGroupCodons[codon]
            if (inGroupCodon != outGroupCodon) and ('N' not in inGroupCodon) and ('N' not in outGroupCodon):
                inGroupAA = geneticCode[inGroupCodon]
                outGroupAA = geneticCode[outGroupCodon]
                numDiff = 0
                site1 = [inGroupCodon[0],outGroupCodon[0]]
                site2 = [inGroupCodon[1],outGroupCodon[1]]
                site3 = [inGroupCodon[2],outGroupCodon[2]]
                if site1[0] != site1[1]:
                    numDiff += 1
                if site2[0] != site2[1]:
                    numDiff += 1
                if site3[0] != site3[1]:
                    numDiff += 1
                if numDiff < 2:
                    numSubs += 1
                    if inGroupAA == outGroupAA:
                        numSynSubs += 1
                    else:
                        numNonSynSubs += 1
                elif numDiff == 2:
                    numSubs += 2
                    if site1[0] != site1[1]:
                        if site2[0] != site2[1]:
                            int1 = site1[1] + inGroupCodon[1:]
                            int2 = site1[0] + outGroupCodon[1:]
                        else:
                            int1 = site1[1] + inGroupCodon[1:]
                            int2 = site1[0] + outGroupCodon[1:]    
                    elif site2[0] != site2[1]:
                        int1 = site1[0] + site2[1] + inGroupCodon[2]
                        int2 = site1[0] + site2[0] + outGroupCodon[2]
                    numSynDiff_a = 0
                    numNonSynDiff_a = 0
                    int1AA = geneticCode[int1]
                    int2AA = geneticCode[int2]
                    if int1AA != inGroupAA:
                        numNonSynDiff_a += 1
                        if int1AA != outGroupAA:
                            numNonSynDiff_a += 1
                        else:
                            numSynDiff_a += 1
                    else:
                        numSynDiff_a += 1
                    numSynDiff_b = 0
                    numNonSynDiff_b = 0
                    if int2AA != inGroupAA:
                        numNonSynDiff_b += 1
                        if int2AA != outGroupAA:
                            numNonSynDiff_b += 1
                        else:
                            numSynDiff_b += 1
                    else:
                        numSynDiff_b += 1
                    if int2AA != '*' and int1AA != '*':
                        if numSynDiff_a > numSynDiff_b:
                            numSynDiff = numSynDiff_a
                            numNonSynDiff = numNonSynDiff_a
                        elif numSynDiff_b > numSynDiff_a:
                            numSynDiff = numSynDiff_b
                            numNonSynDiff = numNonSynDiff_b
                        else:
                            numSynDiff = numSynDiff_a
                            numNonSynDiff = numNonSynDiff_a
                    elif int1AA == '*':
                        if int2AA == '*':
                            numSynDiff = numSynDiff_a
                            numNonSynDiff = numNonSynDiff_a
                        else:
                            numSynDiff = numSynDiff_b
                            numNonSynDiff = numNonSynDiff_b
                    else:
                        numSynDiff = numSynDiff_a
                        numNonSynDiff = numNonSynDiff_a
                    numSynSubs += numSynDiff
                    numNonSynSubs += numNonSynDiff
    inGroupSynSites = 0.0
    inGroupNonSynSites = 0.0
    for seq in seqList:
        sites = countSites(codonDict[seq],code)
        nonSynSites = sites[1]
        synSites = sites[0]
        inGroupSynSites += synSites
        inGroupNonSynSites += nonSynSites
        inGroupSynSites = inGroupSynSites/len(currSeqs)
        inGroupNonSynSites = inGroupNonSynSites/len(currSeqs)   
    inGroupSynSites = inGroupSynSites/len(seqList)
    inGroupNonSynSites = inGroupNonSynSites/len(seqList)
    d = float(numSubs)/(len(outGroupCodons)*3)
    nsSites = (inGroupNonSynSites + outGroupNonSynSites)/2
    sSites = (inGroupSynSites + outGroupSynSites)/2
    dN = numNonSynSubs/nsSites
    dS = numSynSubs/sSites
    if dS > 0:
        dN_dS = dN/dS
    else:
        dN_dS = 'N/A'
    return [numSubs,numSynSubs,numNonSynSubs,d,dS,dN,dN_dS]
        

def popStats(seqList,codonDict,code,bootstrap):
    #Only considers codons with 2 or fewer changes between them and 2 or fewer alleles at the codon of interest. For codons with 2 changes, pathway with fewest number of nonsynonymous changes is assumed. Sites with missing data are partially ignored by removing that sample from the codon-by-codon analysis. Codons with missing data are assumed to have 0.71875 synonymous sites and 2.28125 nonsynonymous sites.
    geneticCodes = {'standard':{"TTT":"F",	"TTC":"F",	"TTA":"L",	"TTG":"L",	"TCT":"S",	"TCC":"S",	"TCA":"S",	"TCG":"S",	"TAT":"Y",	"TAC":"Y",	"TAA":"*",	"TAG":"*",	"TGT":"C",	"TGC":"C",	"TGA":"*",	"TGG":"W",	"CTT":"L",	"CTC":"L",	"CTA":"L",	"CTG":"L",	"CCT":"P",	"CCC":"P",	"CCA":"P",	"CCG":"P",	"CAT":"H",	"CAC":"H",	"CAA":"Q",	"CAG":"Q",	"CGT":"R",	"CGC":"R",	"CGA":"R",	"CGG":"R",	"ATT":"I",	"ATC":"I",	"ATA":"I",	"ATG":"M",	"ACT":"T",	"ACC":"T",	"ACA":"T",	"ACG":"T",	"AAT":"N",	"AAC":"N",	"AAA":"K",	"AAG":"K",	"AGT":"S",	"AGC":"S",	"AGA":"R",	"AGG":"R",	"GTT":"V",	"GTC":"V",	"GTA":"V",	"GTG":"V",	"GCT":"A",	"GCC":"A",	"GCA":"A",	"GCG":"A",	"GAT":"D",	"GAC":"D",	"GAA":"E",	"GAG":"E",	"GGT":"G",	"GGC":"G",	"GGA":"G",	"GGG":"G"},'invertebrateMt':{'CTT': 'L', 'TAG': '*', 'ACA': 'T', 'ACG': 'T', 'ATC': 'I', 'AAC': 'N', 'ATA': 'M', 'AGG': 'S', 'CCT': 'P', 'ACT': 'T', 'AGC': 'S', 'AAG': 'K', 'AGA': 'S', 'CAT': 'H', 'AAT': 'N', 'ATT': 'I', 'CTG': 'L', 'CTA': 'L', 'CTC': 'L', 'CAC': 'H', 'AAA': 'K', 'CCG': 'P', 'AGT': 'S', 'CCA': 'P', 'CAA': 'Q', 'CCC': 'P', 'TAT': 'Y', 'GGT': 'G', 'TGT': 'C', 'CGA': 'R', 'CAG': 'Q', 'TCT': 'S', 'GAT': 'D', 'CGG': 'R', 'TTT': 'F', 'TGC': 'C', 'GGG': 'G', 'TGA': 'W', 'GGA': 'G', 'TGG': 'W', 'GGC': 'G', 'TAC': 'Y', 'TTC': 'F', 'TCG': 'S', 'TTA': 'L', 'TTG': 'L', 'TCC': 'S', 'ACC': 'T', 'TAA': '*', 'GCA': 'A', 'GTA': 'V', 'GCC': 'A', 'GTC': 'V', 'GCG': 'A', 'GTG': 'V', 'GAG': 'E', 'GTT': 'V', 'GCT': 'A', 'GAC': 'D', 'CGT': 'R', 'GAA': 'E', 'TCA': 'S', 'ATG': 'M', 'CGC': 'R'},'vertebrateMt':{'CTT': 'L', 'TAG': '*', 'ACA': 'T', 'ACG': 'T', 'ATC': 'I', 'AAC': 'N', 'ATA': 'M', 'AGG': '*', 'CCT': 'P', 'ACT': 'T', 'AGC': 'S', 'AAG': 'K', 'AGA': '*', 'CAT': 'H', 'AAT': 'N', 'ATT': 'I', 'CTG': 'L', 'CTA': 'L', 'CTC': 'L', 'CAC': 'H', 'AAA': 'K', 'CCG': 'P', 'AGT': 'S', 'CCA': 'P', 'CAA': 'Q', 'CCC': 'P', 'TAT': 'Y', 'GGT': 'G', 'TGT': 'C', 'CGA': 'R', 'CAG': 'Q', 'TCT': 'S', 'GAT': 'D', 'CGG': 'R', 'TTT': 'F', 'TGC': 'C', 'GGG': 'G', 'TGA': 'W', 'GGA': 'G', 'TGG': 'W', 'GGC': 'G', 'TAC': 'Y', 'TTC': 'F', 'TCG': 'S', 'TTA': 'L', 'TTG': 'L', 'TCC': 'S', 'ACC': 'T', 'TAA': '*', 'GCA': 'A', 'GTA': 'V', 'GCC': 'A', 'GTC': 'V', 'GCG': 'A', 'GTG': 'V', 'GAG': 'E', 'GTT': 'V', 'GCT': 'A', 'GAC': 'D', 'CGT': 'R', 'GAA': 'E', 'TCA': 'S', 'ATG': 'M', 'CGC': 'R'}, 'yeastMt':{'CTT': 'T', 'TAG': '*', 'ACA': 'T', 'ACG': 'T', 'ATC': 'I', 'AAC': 'N', 'ATA': 'M', 'AGG': 'R', 'CCT': 'P', 'ACT': 'T', 'AGC': 'S', 'AAG': 'K', 'AGA': 'R', 'CAT': 'H', 'AAT': 'N', 'ATT': 'I', 'CTG': 'T', 'CTA': 'T', 'CTC': 'T', 'CAC': 'H', 'AAA': 'K', 'CCG': 'P', 'AGT': 'S', 'CCA': 'P', 'CAA': 'Q', 'CCC': 'P', 'TAT': 'Y', 'GGT': 'G', 'TGT': 'C', 'CGA': 'R', 'CAG': 'Q', 'TCT': 'S', 'GAT': 'D', 'CGG': 'R', 'TTT': 'F', 'TGC': 'C', 'GGG': 'G', 'TGA': 'W', 'GGA': 'G', 'TGG': 'W', 'GGC': 'G', 'TAC': 'Y', 'TTC': 'F', 'TCG': 'S', 'TTA': 'L', 'TTG': 'L', 'TCC': 'S', 'ACC': 'T', 'TAA': '*', 'GCA': 'A', 'GTA': 'V', 'GCC': 'A', 'GTC': 'V', 'GCG': 'A', 'GTG': 'V', 'GAG': 'E', 'GTT': 'V', 'GCT': 'A', 'GAC': 'D', 'CGT': 'R', 'GAA': 'E', 'TCA': 'S', 'ATG': 'M', 'CGC': 'R'}, 'coelenterateMt':{'CTT': 'L', 'TAG': '*', 'ACA': 'T', 'ACG': 'T', 'ATC': 'I', 'AAC': 'N', 'ATA': 'I', 'AGG': 'R', 'CCT': 'P', 'ACT': 'T', 'AGC': 'S', 'AAG': 'K', 'AGA': 'R', 'CAT': 'H', 'AAT': 'N', 'ATT': 'I', 'CTG': 'L', 'CTA': 'L', 'CTC': 'L', 'CAC': 'H', 'AAA': 'K', 'CCG': 'P', 'AGT': 'S', 'CCA': 'P', 'CAA': 'Q', 'CCC': 'P', 'TAT': 'Y', 'GGT': 'G', 'TGT': 'C', 'CGA': 'R', 'CAG': 'Q', 'TCT': 'S', 'GAT': 'D', 'CGG': 'R', 'TTT': 'F', 'TGC': 'C', 'GGG': 'G', 'TGA': 'W', 'GGA': 'G', 'TGG': 'W', 'GGC': 'G', 'TAC': 'Y', 'TTC': 'F', 'TCG': 'S', 'TTA': 'L', 'TTG': 'L', 'TCC': 'S', 'ACC': 'T', 'TAA': '*', 'GCA': 'A', 'GTA': 'V', 'GCC': 'A', 'GTC': 'V', 'GCG': 'A', 'GTG': 'V', 'GAG': 'E', 'GTT': 'V', 'GCT': 'A', 'GAC': 'D', 'CGT': 'R', 'GAA': 'E', 'TCA': 'S', 'ATG': 'M', 'CGC': 'R'},'ciliateNuc':{'CTT': 'L', 'TAG': 'Q', 'ACA': 'T', 'ACG': 'T', 'ATC': 'I', 'AAC': 'N', 'ATA': 'I', 'AGG': 'R', 'CCT': 'P', 'ACT': 'T', 'AGC': 'S', 'AAG': 'K', 'AGA': 'R', 'CAT': 'H', 'AAT': 'N', 'ATT': 'I', 'CTG': 'L', 'CTA': 'L', 'CTC': 'L', 'CAC': 'H', 'AAA': 'K', 'CCG': 'P', 'AGT': 'S', 'CCA': 'P', 'CAA': 'Q', 'CCC': 'P', 'TAT': 'Y', 'GGT': 'G', 'TGT': 'C', 'CGA': 'R', 'CAG': 'Q', 'TCT': 'S', 'GAT': 'D', 'CGG': 'R', 'TTT': 'F', 'TGC': 'C', 'GGG': 'G', 'TGA': '*', 'GGA': 'G', 'TGG': 'W', 'GGC': 'G', 'TAC': 'Y', 'TTC': 'F', 'TCG': 'S', 'TTA': 'L', 'TTG': 'L', 'TCC': 'S', 'ACC': 'T', 'TAA': 'Q', 'GCA': 'A', 'GTA': 'V', 'GCC': 'A', 'GTC': 'V', 'GCG': 'A', 'GTG': 'V', 'GAG': 'E', 'GTT': 'V', 'GCT': 'A', 'GAC': 'D', 'CGT': 'R', 'GAA': 'E', 'TCA': 'S', 'ATG': 'M', 'CGC': 'R'},'echinodermMt':{'CTT': 'L', 'TAG': '*', 'ACA': 'T', 'ACG': 'T', 'ATC': 'I', 'AAC': 'N', 'ATA': 'I', 'AGG': 'S', 'CCT': 'P', 'ACT': 'T', 'AGC': 'S', 'AAG': 'K', 'AGA': 'S', 'CAT': 'H', 'AAT': 'N', 'ATT': 'I', 'CTG': 'L', 'CTA': 'L', 'CTC': 'L', 'CAC': 'H', 'AAA': 'N', 'CCG': 'P', 'AGT': 'S', 'CCA': 'P', 'CAA': 'Q', 'CCC': 'P', 'TAT': 'Y', 'GGT': 'G', 'TGT': 'C', 'CGA': 'R', 'CAG': 'Q', 'TCT': 'S', 'GAT': 'D', 'CGG': 'R', 'TTT': 'F', 'TGC': 'C', 'GGG': 'G', 'TGA': 'W', 'GGA': 'G', 'TGG': 'W', 'GGC': 'G', 'TAC': 'Y', 'TTC': 'F', 'TCG': 'S', 'TTA': 'L', 'TTG': 'L', 'TCC': 'S', 'ACC': 'T', 'TAA': '*', 'GCA': 'A', 'GTA': 'V', 'GCC': 'A', 'GTC': 'V', 'GCG': 'A', 'GTG': 'V', 'GAG': 'E', 'GTT': 'V', 'GCT': 'A', 'GAC': 'D', 'CGT': 'R', 'GAA': 'E', 'TCA': 'S', 'ATG': 'M', 'CGC': 'R'}, 'euplotidNuc':{'CTT': 'L', 'TAG': '*', 'ACA': 'T', 'ACG': 'T', 'ATC': 'I', 'AAC': 'N', 'ATA': 'I', 'AGG': 'R', 'CCT': 'P', 'ACT': 'T', 'AGC': 'S', 'AAG': 'K', 'AGA': 'R', 'CAT': 'H', 'AAT': 'N', 'ATT': 'I', 'CTG': 'L', 'CTA': 'L', 'CTC': 'L', 'CAC': 'H', 'AAA': 'K', 'CCG': 'P', 'AGT': 'S', 'CCA': 'P', 'CAA': 'Q', 'CCC': 'P', 'TAT': 'Y', 'GGT': 'G', 'TGT': 'C', 'CGA': 'R', 'CAG': 'Q', 'TCT': 'S', 'GAT': 'D', 'CGG': 'R', 'TTT': 'F', 'TGC': 'C', 'GGG': 'G', 'TGA': 'C', 'GGA': 'G', 'TGG': 'W', 'GGC': 'G', 'TAC': 'Y', 'TTC': 'F', 'TCG': 'S', 'TTA': 'L', 'TTG': 'L', 'TCC': 'S', 'ACC': 'T', 'TAA': '*', 'GCA': 'A', 'GTA': 'V', 'GCC': 'A', 'GTC': 'V', 'GCG': 'A', 'GTG': 'V', 'GAG': 'E', 'GTT': 'V', 'GCT': 'A', 'GAC': 'D', 'CGT': 'R', 'GAA': 'E', 'TCA': 'S', 'ATG': 'M', 'CGC': 'R'}, 'bacterial':{'CTT': 'L', 'TAG': '*', 'ACA': 'T', 'ACG': 'T', 'ATC': 'I', 'AAC': 'N', 'ATA': 'I', 'AGG': 'R', 'CCT': 'P', 'ACT': 'T', 'AGC': 'S', 'AAG': 'K', 'AGA': 'R', 'CAT': 'H', 'AAT': 'N', 'ATT': 'I', 'CTG': 'L', 'CTA': 'L', 'CTC': 'L', 'CAC': 'H', 'AAA': 'K', 'CCG': 'P', 'AGT': 'S', 'CCA': 'P', 'CAA': 'Q', 'CCC': 'P', 'TAT': 'Y', 'GGT': 'G', 'TGT': 'C', 'CGA': 'R', 'CAG': 'Q', 'TCT': 'S', 'GAT': 'D', 'CGG': 'R', 'TTT': 'F', 'TGC': 'C', 'GGG': 'G', 'TGA': '*', 'GGA': 'G', 'TGG': 'W', 'GGC': 'G', 'TAC': 'Y', 'TTC': 'F', 'TCG': 'S', 'TTA': 'L', 'TTG': 'L', 'TCC': 'S', 'ACC': 'T', 'TAA': '*', 'GCA': 'A', 'GTA': 'V', 'GCC': 'A', 'GTC': 'V', 'GCG': 'A', 'GTG': 'V', 'GAG': 'E', 'GTT': 'V', 'GCT': 'A', 'GAC': 'D', 'CGT': 'R', 'GAA': 'E', 'TCA': 'S', 'ATG': 'M', 'CGC': 'R'},'yeastNuc':{'CTT': 'L', 'TAG': '*', 'ACA': 'T', 'ACG': 'T', 'ATC': 'I', 'AAC': 'N', 'ATA': 'I', 'AGG': 'R', 'CCT': 'P', 'ACT': 'T', 'AGC': 'S', 'AAG': 'K', 'AGA': 'R', 'CAT': 'H', 'AAT': 'N', 'ATT': 'I', 'CTG': 'S', 'CTA': 'L', 'CTC': 'L', 'CAC': 'H', 'AAA': 'K', 'CCG': 'P', 'AGT': 'S', 'CCA': 'P', 'CAA': 'Q', 'CCC': 'P', 'TAT': 'Y', 'GGT': 'G', 'TGT': 'C', 'CGA': 'R', 'CAG': 'Q', 'TCT': 'S', 'GAT': 'D', 'CGG': 'R', 'TTT': 'F', 'TGC': 'C', 'GGG': 'G', 'TGA': '*', 'GGA': 'G', 'TGG': 'W', 'GGC': 'G', 'TAC': 'Y', 'TTC': 'F', 'TCG': 'S', 'TTA': 'L', 'TTG': 'L', 'TCC': 'S', 'ACC': 'T', 'TAA': '*', 'GCA': 'A', 'GTA': 'V', 'GCC': 'A', 'GTC': 'V', 'GCG': 'A', 'GTG': 'V', 'GAG': 'E', 'GTT': 'V', 'GCT': 'A', 'GAC': 'D', 'CGT': 'R', 'GAA': 'E', 'TCA': 'S', 'ATG': 'M', 'CGC': 'R'}, 'ascidianMt':{'CTT': 'L', 'TAG': '*', 'ACA': 'T', 'ACG': 'T', 'ATC': 'I', 'AAC': 'N', 'ATA': 'M', 'AGG': 'G', 'CCT': 'P', 'ACT': 'T', 'AGC': 'S', 'AAG': 'K', 'AGA': 'G', 'CAT': 'H', 'AAT': 'N', 'ATT': 'I', 'CTG': 'L', 'CTA': 'L', 'CTC': 'L', 'CAC': 'H', 'AAA': 'K', 'CCG': 'P', 'AGT': 'S', 'CCA': 'P', 'CAA': 'Q', 'CCC': 'P', 'TAT': 'Y', 'GGT': 'G', 'TGT': 'C', 'CGA': 'R', 'CAG': 'Q', 'TCT': 'S', 'GAT': 'D', 'CGG': 'R', 'TTT': 'F', 'TGC': 'C', 'GGG': 'G', 'TGA': 'W', 'GGA': 'G', 'TGG': 'W', 'GGC': 'G', 'TAC': 'Y', 'TTC': 'F', 'TCG': 'S', 'TTA': 'L', 'TTG': 'L', 'TCC': 'S', 'ACC': 'T', 'TAA': '*', 'GCA': 'A', 'GTA': 'V', 'GCC': 'A', 'GTC': 'V', 'GCG': 'A', 'GTG': 'V', 'GAG': 'E', 'GTT': 'V', 'GCT': 'A', 'GAC': 'D', 'CGT': 'R', 'GAA': 'E', 'TCA': 'S', 'ATG': 'M', 'CGC': 'R'},'flatwormMt':{'CTT': 'L', 'TAG': '*', 'ACA': 'T', 'ACG': 'T', 'ATC': 'I', 'AAC': 'N', 'ATA': 'I', 'AGG': 'S', 'CCT': 'P', 'ACT': 'T', 'AGC': 'S', 'AAG': 'K', 'AGA': 'S', 'CAT': 'H', 'AAT': 'N', 'ATT': 'I', 'CTG': 'L', 'CTA': 'L', 'CTC': 'L', 'CAC': 'H', 'AAA': 'N', 'CCG': 'P', 'AGT': 'S', 'CCA': 'P', 'CAA': 'Q', 'CCC': 'P', 'TAT': 'Y', 'GGT': 'G', 'TGT': 'C', 'CGA': 'R', 'CAG': 'Q', 'TCT': 'S', 'GAT': 'D', 'CGG': 'R', 'TTT': 'F', 'TGC': 'C', 'GGG': 'G', 'TGA': 'W', 'GGA': 'G', 'TGG': 'W', 'GGC': 'G', 'TAC': 'Y', 'TTC': 'F', 'TCG': 'S', 'TTA': 'L', 'TTG': 'L', 'TCC': 'S', 'ACC': 'T', 'TAA': 'Y', 'GCA': 'A', 'GTA': 'V', 'GCC': 'A', 'GTC': 'V', 'GCG': 'A', 'GTG': 'V', 'GAG': 'E', 'GTT': 'V', 'GCT': 'A', 'GAC': 'D', 'CGT': 'R', 'GAA': 'E', 'TCA': 'S', 'ATG': 'M', 'CGC': 'R'},'chlorophyceanMt':{'CTT': 'L', 'TAG': 'L', 'ACA': 'T', 'ACG': 'T', 'ATC': 'I', 'AAC': 'N', 'ATA': 'I', 'AGG': 'R', 'CCT': 'P', 'ACT': 'T', 'AGC': 'S', 'AAG': 'K', 'AGA': 'R', 'CAT': 'H', 'AAT': 'N', 'ATT': 'I', 'CTG': 'L', 'CTA': 'L', 'CTC': 'L', 'CAC': 'H', 'AAA': 'K', 'CCG': 'P', 'AGT': 'S', 'CCA': 'P', 'CAA': 'Q', 'CCC': 'P', 'TAT': 'Y', 'GGT': 'G', 'TGT': 'C', 'CGA': 'R', 'CAG': 'Q', 'TCT': 'S', 'GAT': 'D', 'CGG': 'R', 'TTT': 'F', 'TGC': 'C', 'GGG': 'G', 'TGA': '*', 'GGA': 'G', 'TGG': 'W', 'GGC': 'G', 'TAC': 'Y', 'TTC': 'F', 'TCG': 'S', 'TTA': 'L', 'TTG': 'L', 'TCC': 'S', 'ACC': 'T', 'TAA': '*', 'GCA': 'A', 'GTA': 'V', 'GCC': 'A', 'GTC': 'V', 'GCG': 'A', 'GTG': 'V', 'GAG': 'E', 'GTT': 'V', 'GCT': 'A', 'GAC': 'D', 'CGT': 'R', 'GAA': 'E', 'TCA': 'S', 'ATG': 'M', 'CGC': 'R'},'trematodeMt':{'CTT': 'L', 'TAG': '*', 'ACA': 'T', 'ACG': 'T', 'ATC': 'I', 'AAC': 'N', 'ATA': 'M', 'AGG': 'S', 'CCT': 'P', 'ACT': 'T', 'AGC': 'S', 'AAG': 'K', 'AGA': 'S', 'CAT': 'H', 'AAT': 'N', 'ATT': 'I', 'CTG': 'L', 'CTA': 'L', 'CTC': 'L', 'CAC': 'H', 'AAA': 'N', 'CCG': 'P', 'AGT': 'S', 'CCA': 'P', 'CAA': 'Q', 'CCC': 'P', 'TAT': 'Y', 'GGT': 'G', 'TGT': 'C', 'CGA': 'R', 'CAG': 'Q', 'TCT': 'S', 'GAT': 'D', 'CGG': 'R', 'TTT': 'F', 'TGC': 'C', 'GGG': 'G', 'TGA': 'W', 'GGA': 'G', 'TGG': 'W', 'GGC': 'G', 'TAC': 'Y', 'TTC': 'F', 'TCG': 'S', 'TTA': 'L', 'TTG': 'L', 'TCC': 'S', 'ACC': 'T', 'TAA': '*', 'GCA': 'A', 'GTA': 'V', 'GCC': 'A', 'GTC': 'V', 'GCG': 'A', 'GTG': 'V', 'GAG': 'E', 'GTT': 'V', 'GCT': 'A', 'GAC': 'D', 'CGT': 'R', 'GAA': 'E', 'TCA': 'S', 'ATG': 'M', 'CGC': 'R'},'pterobranchiaMt':{'CTT': 'L', 'TAG': '*', 'ACA': 'T', 'ACG': 'T', 'ATC': 'I', 'AAC': 'N', 'ATA': 'I', 'AGG': 'K', 'CCT': 'P', 'ACT': 'T', 'AGC': 'S', 'AAG': 'K', 'AGA': 'S', 'CAT': 'H', 'AAT': 'N', 'ATT': 'I', 'CTG': 'L', 'CTA': 'L', 'CTC': 'L', 'CAC': 'H', 'AAA': 'K', 'CCG': 'P', 'AGT': 'S', 'CCA': 'P', 'CAA': 'Q', 'CCC': 'P', 'TAT': 'Y', 'GGT': 'G', 'TGT': 'C', 'CGA': 'R', 'CAG': 'Q', 'TCT': 'S', 'GAT': 'D', 'CGG': 'R', 'TTT': 'F', 'TGC': 'C', 'GGG': 'G', 'TGA': 'W', 'GGA': 'G', 'TGG': 'W', 'GGC': 'G', 'TAC': 'Y', 'TTC': 'F', 'TCG': 'S', 'TTA': 'L', 'TTG': 'L', 'TCC': 'S', 'ACC': 'T', 'TAA': '*', 'GCA': 'A', 'GTA': 'V', 'GCC': 'A', 'GTC': 'V', 'GCG': 'A', 'GTG': 'V', 'GAG': 'E', 'GTT': 'V', 'GCT': 'A', 'GAC': 'D', 'CGT': 'R', 'GAA': 'E', 'TCA': 'S', 'ATG': 'M', 'CGC': 'R'}}
    geneticCode = geneticCodes[code]
    an = 0.0
    a2 = 0.0
    i = 1
    N = len(seqList)
    if N < 2:
        return ['N/A','N/A','N/A','N/A','N/A','N/A','N/A','N/A','N/A','N/A','N/A','N/A','N/A','N/A']
    else:
        while i < N:
            currAn = 1.0/i
            currA2 = 1.0/(i*i)
            an += currAn
            a2 += currA2
            i += 1
        b1 = (N + 1)/(3 * (N - 1))
        b2 = ((2*N*N) + (2*N) + (6))/((9*N*N)-(9*N))
        c1 = b1 + (1/an)
        c2 = b2 - ((N+2)/(an*N)) + (a2/(an*an))
        e1 = c1/an
        e2 = c2/((an*an)+a2)
        currSeqs = []
        for seq in seqList:
            currSeqs.append(codonDict[seq])
        seqLength = len(currSeqs[0])
        i = 0
        polymorphicSites = {}
        siteList = []
        freqDict = {}
        while i < seqLength:
            currSite = []
            for sequence in currSeqs:
                currSite.append(sequence[i])
            x = 0
            xs = []
            for j in range(len(currSite)):
                if 'N' in currSite[j] or '-' in currSite[j]:
                    xs.append(j-x)
                    x += 1
            for item in xs:
                del currSite[item]
            xs = []
            if len(currSite) > 1:
                compareCodon = currSite[0]
                currentAlleles = {compareCodon:1}
                for codon in currSite[1:]:
                    if compareCodon != codon:
                        if codon not in currentAlleles:
                            currentAlleles[codon] = 1
                            altPoly = codon
                        elif codon in currentAlleles:
                            currentAlleles[codon] += 1
                    else:
                        currentAlleles[compareCodon] += 1
                if len(currentAlleles) == 2:
                    siteList.append(i)
                    polymorphicSites[i] = (compareCodon,altPoly)
                    p = (currentAlleles[compareCodon])/float(len(currSite))
                    q = (currentAlleles[altPoly])/float(len(currSite))
                    freqDict[i] = (p,q)
            i += 1
        numPolymorphisms = 0
        numSynPoly = 0
        numNonSynPoly = 0
        synPolyList = []
        nonSynPolyList = []
        sum2pq = 0.0
        synSum2pq = 0.0
        nonSynSum2pq = 0.0
        for codon in siteList:
            alleles = polymorphicSites[codon]
            allele1 = alleles[0]
            allele2 = alleles[1]
            aa1 = geneticCode[allele1]
            aa2 = geneticCode[allele2]
            alleleFreqs = freqDict[codon]
            allele1Freq = alleleFreqs[0]
            allele2Freq = alleleFreqs[1]
            sum2pq += 2*allele1Freq*allele2Freq
            if aa1 == aa2:
                synSum2pq += 2*allele1Freq*allele2Freq
                synPolyList.append(codon)
            else:
                nonSynSum2pq += 2*allele1Freq*allele2Freq
                nonSynPolyList.append(codon)
            numDiff = 0
            i = 0
            while i < 3:
                nuc1 = allele1[i]
                nuc2 = allele2[i]
                if nuc1 != nuc2:
                    numDiff += 1
                i += 1
            if numDiff < 2:
                numPolymorphisms += numDiff
                if aa1 == aa2:
                    numSynPoly += 1  
                else:
                    numNonSynPoly += 1
                    nonSynPolyList.append(codon)         
            elif numDiff == 2:
                site1 = (allele1[0],allele2[0])
                site2 = (allele1[1],allele2[1])
                if site1[0] != site1[1]:
                    if site2[0] != site2[1]:
                        int1 = site1[1] + allele1[1:]
                        int2 = site1[0] + allele2[1:]
                    else:
                        int1 = site1[1] + allele1[1:]
                        int2 = site1[0] + allele2[1:]    
                elif site2[0] != site2[1]:
                    int1 = site1[0] + site2[1] + allele1[2]
                    int2 = site1[0] + site2[0] + allele2[2]
                numSynDiff_a = 0
                numNonSynDiff_a = 0
                int1AA = geneticCode[int1]
                int2AA = geneticCode[int2]
                if int1AA != aa1:
                    numNonSynDiff_a += 1
                    if int1AA != aa2:
                        numNonSynDiff_a += 1
                    else:
                        numSynDiff_a += 1
                else:
                    numSynDiff_a += 1
                numSynDiff_b = 0
                numNonSynDiff_b = 0
                if int2AA != aa1:
                    numNonSynDiff_b += 1
                    if int2AA != aa2:
                        numNonSynDiff_b += 1
                    else:
                        numSynDiff_b += 1
                else:
                    numSynDiff_b += 2
                if int2AA != '*' and int1AA != '*':
                    if numSynDiff_a > numSynDiff_b:
                        numSynDiff = numSynDiff_a
                        numNonSynDiff = numNonSynDiff_a
                    elif numSynDiff_b > numSynDiff_a:
                        numSynDiff = numSynDiff_b
                        numNonSynDiff = numNonSynDiff_b
                    else:
                        numSynDiff = numSynDiff_a
                        numNonSynDiff = numNonSynDiff_a
                elif int1AA == '*':
                    if int2AA == '*':
                        numSynDiff = numSynDiff_a
                        numNonSynDiff = numNonSynDiff_a
                    else:
                        numSynDiff = numSynDiff_b
                        numNonSynDiff = numNonSynDiff_b
                else:
                    numSynDiff = numSynDiff_a
                    numNonSynDiff = numNonSynDiff_a
                numSynPoly += numSynDiff
                numNonSynPoly += numNonSynDiff
                numPolymorphisms += 2
                if bootstrap == False:
                    logfile = open('logfile.txt','a')
                    logfile.write('Codon # ' + str(codon) + ' has multiple hits: ' + allele1 + ' (' + aa1 + '), ' + allele2 + ' (' + aa2 + ')\n\tAssuming the following intermediate codon states: ' + int1 + ' (' + int1AA + '), ' + int2 + ' (' + int2AA + ')\n')
                    logfile.close()
        #Start radical/conservative code here (nonSynPolyList)
        totalSites = len(currSeqs[0])*3.0
        synSites = 0.0
        nonSynSites = 0.0
        for seq in seqList:
            codonList = codonDict[seq]
            sites = countSites(codonList,code)
            synSites += sites[0]
            nonSynSites += sites[1]
        synSites = synSites/len(currSeqs)
        nonSynSites = nonSynSites/len(currSeqs)
        pi = ((N/(N-1))*(sum2pq/totalSites))
        piA = ((N/(N-1))*(nonSynSum2pq/nonSynSites))
        piS = ((N/(N-1))*(synSum2pq/synSites))
        theta = numPolymorphisms/(an*totalSites)
        thetaA = numNonSynPoly/(an*nonSynSites)
        thetaS = numSynPoly/(an*synSites)
        if piS > 0:
            piA_piS = piA/piS
        else:
            piA_piS = 'N/A'
        if thetaS > 0:
            thetaA_thetaS = thetaA/thetaS
        else:
            thetaA_thetaS = 'N/A'
        d = pi - theta
        d_syn = piS - thetaS
        d_nonsyn = piA - thetaA
        variance = ((e1*(numPolymorphisms/totalSites)) + (e2*(numPolymorphisms/totalSites)*((numPolymorphisms-1)/totalSites)))
        variance_syn = ((e1*(numSynPoly/synSites)) + (e2*(numSynPoly/synSites)*((numSynPoly-1)/synSites)))
        variance_nonsyn = ((e1*(numNonSynPoly/nonSynSites)) + (e2*(numNonSynPoly/nonSynSites)*((numNonSynPoly - 1)/nonSynSites)))
        if variance > 0:
            tajimasD = d/math.sqrt(variance)
        else:
            tajimasD = 'N/A'    
        if variance_syn > 0:
            tajimasD_S = d_syn/math.sqrt(variance_syn)
        else:
            tajimasD_S = 'N/A'
        if variance_nonsyn > 0:
            tajimasD_A = d_nonsyn/math.sqrt(variance_nonsyn)
        else:
            tajimasD_A = 'N/A'
        return [numPolymorphisms,numSynPoly,numNonSynPoly,pi,piS,piA,piA_piS,theta,thetaS,thetaA,thetaA_thetaS,tajimasD,tajimasD_A,tajimasD_S]     
             
                
            
            
            
            

def formatGenCode():
    AAlist = 'FFLLSSSSYY**CCWWLLLLPPPPHHQQRRRRIIIMTTTTNNKKSSSKVVVVAAAADDEEGGGG'
    firstNucList = 'TTTTTTTTTTTTTTTTCCCCCCCCCCCCCCCCAAAAAAAAAAAAAAAAGGGGGGGGGGGGGGGG'
    secondNucList = 'TTTTCCCCAAAAGGGGTTTTCCCCAAAAGGGGTTTTCCCCAAAAGGGGTTTTCCCCAAAAGGGG'
    thirdNucList = 'TCAGTCAGTCAGTCAGTCAGTCAGTCAGTCAGTCAGTCAGTCAGTCAGTCAGTCAGTCAGTCAG'
    codeDict = {}
    i = 0
    for aa in AAlist:
        codon = firstNucList[i] + secondNucList[i] + thirdNucList[i]
        codeDict[codon] = aa
        i += 1
    return str(codeDict)

def countSites(codonList,code):
    geneticCodes = {'standard':{"TTT":"F",	"TTC":"F",	"TTA":"L",	"TTG":"L",	"TCT":"S",	"TCC":"S",	"TCA":"S",	"TCG":"S",	"TAT":"Y",	"TAC":"Y",	"TAA":"*",	"TAG":"*",	"TGT":"C",	"TGC":"C",	"TGA":"*",	"TGG":"W",	"CTT":"L",	"CTC":"L",	"CTA":"L",	"CTG":"L",	"CCT":"P",	"CCC":"P",	"CCA":"P",	"CCG":"P",	"CAT":"H",	"CAC":"H",	"CAA":"Q",	"CAG":"Q",	"CGT":"R",	"CGC":"R",	"CGA":"R",	"CGG":"R",	"ATT":"I",	"ATC":"I",	"ATA":"I",	"ATG":"M",	"ACT":"T",	"ACC":"T",	"ACA":"T",	"ACG":"T",	"AAT":"N",	"AAC":"N",	"AAA":"K",	"AAG":"K",	"AGT":"S",	"AGC":"S",	"AGA":"R",	"AGG":"R",	"GTT":"V",	"GTC":"V",	"GTA":"V",	"GTG":"V",	"GCT":"A",	"GCC":"A",	"GCA":"A",	"GCG":"A",	"GAT":"D",	"GAC":"D",	"GAA":"E",	"GAG":"E",	"GGT":"G",	"GGC":"G",	"GGA":"G",	"GGG":"G"},'invertebrateMt':{'CTT': 'L', 'TAG': '*', 'ACA': 'T', 'ACG': 'T', 'ATC': 'I', 'AAC': 'N', 'ATA': 'M', 'AGG': 'S', 'CCT': 'P', 'ACT': 'T', 'AGC': 'S', 'AAG': 'K', 'AGA': 'S', 'CAT': 'H', 'AAT': 'N', 'ATT': 'I', 'CTG': 'L', 'CTA': 'L', 'CTC': 'L', 'CAC': 'H', 'AAA': 'K', 'CCG': 'P', 'AGT': 'S', 'CCA': 'P', 'CAA': 'Q', 'CCC': 'P', 'TAT': 'Y', 'GGT': 'G', 'TGT': 'C', 'CGA': 'R', 'CAG': 'Q', 'TCT': 'S', 'GAT': 'D', 'CGG': 'R', 'TTT': 'F', 'TGC': 'C', 'GGG': 'G', 'TGA': 'W', 'GGA': 'G', 'TGG': 'W', 'GGC': 'G', 'TAC': 'Y', 'TTC': 'F', 'TCG': 'S', 'TTA': 'L', 'TTG': 'L', 'TCC': 'S', 'ACC': 'T', 'TAA': '*', 'GCA': 'A', 'GTA': 'V', 'GCC': 'A', 'GTC': 'V', 'GCG': 'A', 'GTG': 'V', 'GAG': 'E', 'GTT': 'V', 'GCT': 'A', 'GAC': 'D', 'CGT': 'R', 'GAA': 'E', 'TCA': 'S', 'ATG': 'M', 'CGC': 'R'},'vertebrateMt':{'CTT': 'L', 'TAG': '*', 'ACA': 'T', 'ACG': 'T', 'ATC': 'I', 'AAC': 'N', 'ATA': 'M', 'AGG': '*', 'CCT': 'P', 'ACT': 'T', 'AGC': 'S', 'AAG': 'K', 'AGA': '*', 'CAT': 'H', 'AAT': 'N', 'ATT': 'I', 'CTG': 'L', 'CTA': 'L', 'CTC': 'L', 'CAC': 'H', 'AAA': 'K', 'CCG': 'P', 'AGT': 'S', 'CCA': 'P', 'CAA': 'Q', 'CCC': 'P', 'TAT': 'Y', 'GGT': 'G', 'TGT': 'C', 'CGA': 'R', 'CAG': 'Q', 'TCT': 'S', 'GAT': 'D', 'CGG': 'R', 'TTT': 'F', 'TGC': 'C', 'GGG': 'G', 'TGA': 'W', 'GGA': 'G', 'TGG': 'W', 'GGC': 'G', 'TAC': 'Y', 'TTC': 'F', 'TCG': 'S', 'TTA': 'L', 'TTG': 'L', 'TCC': 'S', 'ACC': 'T', 'TAA': '*', 'GCA': 'A', 'GTA': 'V', 'GCC': 'A', 'GTC': 'V', 'GCG': 'A', 'GTG': 'V', 'GAG': 'E', 'GTT': 'V', 'GCT': 'A', 'GAC': 'D', 'CGT': 'R', 'GAA': 'E', 'TCA': 'S', 'ATG': 'M', 'CGC': 'R'}, 'yeastMt':{'CTT': 'T', 'TAG': '*', 'ACA': 'T', 'ACG': 'T', 'ATC': 'I', 'AAC': 'N', 'ATA': 'M', 'AGG': 'R', 'CCT': 'P', 'ACT': 'T', 'AGC': 'S', 'AAG': 'K', 'AGA': 'R', 'CAT': 'H', 'AAT': 'N', 'ATT': 'I', 'CTG': 'T', 'CTA': 'T', 'CTC': 'T', 'CAC': 'H', 'AAA': 'K', 'CCG': 'P', 'AGT': 'S', 'CCA': 'P', 'CAA': 'Q', 'CCC': 'P', 'TAT': 'Y', 'GGT': 'G', 'TGT': 'C', 'CGA': 'R', 'CAG': 'Q', 'TCT': 'S', 'GAT': 'D', 'CGG': 'R', 'TTT': 'F', 'TGC': 'C', 'GGG': 'G', 'TGA': 'W', 'GGA': 'G', 'TGG': 'W', 'GGC': 'G', 'TAC': 'Y', 'TTC': 'F', 'TCG': 'S', 'TTA': 'L', 'TTG': 'L', 'TCC': 'S', 'ACC': 'T', 'TAA': '*', 'GCA': 'A', 'GTA': 'V', 'GCC': 'A', 'GTC': 'V', 'GCG': 'A', 'GTG': 'V', 'GAG': 'E', 'GTT': 'V', 'GCT': 'A', 'GAC': 'D', 'CGT': 'R', 'GAA': 'E', 'TCA': 'S', 'ATG': 'M', 'CGC': 'R'}, 'coelenterateMt':{'CTT': 'L', 'TAG': '*', 'ACA': 'T', 'ACG': 'T', 'ATC': 'I', 'AAC': 'N', 'ATA': 'I', 'AGG': 'R', 'CCT': 'P', 'ACT': 'T', 'AGC': 'S', 'AAG': 'K', 'AGA': 'R', 'CAT': 'H', 'AAT': 'N', 'ATT': 'I', 'CTG': 'L', 'CTA': 'L', 'CTC': 'L', 'CAC': 'H', 'AAA': 'K', 'CCG': 'P', 'AGT': 'S', 'CCA': 'P', 'CAA': 'Q', 'CCC': 'P', 'TAT': 'Y', 'GGT': 'G', 'TGT': 'C', 'CGA': 'R', 'CAG': 'Q', 'TCT': 'S', 'GAT': 'D', 'CGG': 'R', 'TTT': 'F', 'TGC': 'C', 'GGG': 'G', 'TGA': 'W', 'GGA': 'G', 'TGG': 'W', 'GGC': 'G', 'TAC': 'Y', 'TTC': 'F', 'TCG': 'S', 'TTA': 'L', 'TTG': 'L', 'TCC': 'S', 'ACC': 'T', 'TAA': '*', 'GCA': 'A', 'GTA': 'V', 'GCC': 'A', 'GTC': 'V', 'GCG': 'A', 'GTG': 'V', 'GAG': 'E', 'GTT': 'V', 'GCT': 'A', 'GAC': 'D', 'CGT': 'R', 'GAA': 'E', 'TCA': 'S', 'ATG': 'M', 'CGC': 'R'},'ciliateNuc':{'CTT': 'L', 'TAG': 'Q', 'ACA': 'T', 'ACG': 'T', 'ATC': 'I', 'AAC': 'N', 'ATA': 'I', 'AGG': 'R', 'CCT': 'P', 'ACT': 'T', 'AGC': 'S', 'AAG': 'K', 'AGA': 'R', 'CAT': 'H', 'AAT': 'N', 'ATT': 'I', 'CTG': 'L', 'CTA': 'L', 'CTC': 'L', 'CAC': 'H', 'AAA': 'K', 'CCG': 'P', 'AGT': 'S', 'CCA': 'P', 'CAA': 'Q', 'CCC': 'P', 'TAT': 'Y', 'GGT': 'G', 'TGT': 'C', 'CGA': 'R', 'CAG': 'Q', 'TCT': 'S', 'GAT': 'D', 'CGG': 'R', 'TTT': 'F', 'TGC': 'C', 'GGG': 'G', 'TGA': '*', 'GGA': 'G', 'TGG': 'W', 'GGC': 'G', 'TAC': 'Y', 'TTC': 'F', 'TCG': 'S', 'TTA': 'L', 'TTG': 'L', 'TCC': 'S', 'ACC': 'T', 'TAA': 'Q', 'GCA': 'A', 'GTA': 'V', 'GCC': 'A', 'GTC': 'V', 'GCG': 'A', 'GTG': 'V', 'GAG': 'E', 'GTT': 'V', 'GCT': 'A', 'GAC': 'D', 'CGT': 'R', 'GAA': 'E', 'TCA': 'S', 'ATG': 'M', 'CGC': 'R'},'echinodermMt':{'CTT': 'L', 'TAG': '*', 'ACA': 'T', 'ACG': 'T', 'ATC': 'I', 'AAC': 'N', 'ATA': 'I', 'AGG': 'S', 'CCT': 'P', 'ACT': 'T', 'AGC': 'S', 'AAG': 'K', 'AGA': 'S', 'CAT': 'H', 'AAT': 'N', 'ATT': 'I', 'CTG': 'L', 'CTA': 'L', 'CTC': 'L', 'CAC': 'H', 'AAA': 'N', 'CCG': 'P', 'AGT': 'S', 'CCA': 'P', 'CAA': 'Q', 'CCC': 'P', 'TAT': 'Y', 'GGT': 'G', 'TGT': 'C', 'CGA': 'R', 'CAG': 'Q', 'TCT': 'S', 'GAT': 'D', 'CGG': 'R', 'TTT': 'F', 'TGC': 'C', 'GGG': 'G', 'TGA': 'W', 'GGA': 'G', 'TGG': 'W', 'GGC': 'G', 'TAC': 'Y', 'TTC': 'F', 'TCG': 'S', 'TTA': 'L', 'TTG': 'L', 'TCC': 'S', 'ACC': 'T', 'TAA': '*', 'GCA': 'A', 'GTA': 'V', 'GCC': 'A', 'GTC': 'V', 'GCG': 'A', 'GTG': 'V', 'GAG': 'E', 'GTT': 'V', 'GCT': 'A', 'GAC': 'D', 'CGT': 'R', 'GAA': 'E', 'TCA': 'S', 'ATG': 'M', 'CGC': 'R'}, 'euplotidNuc':{'CTT': 'L', 'TAG': '*', 'ACA': 'T', 'ACG': 'T', 'ATC': 'I', 'AAC': 'N', 'ATA': 'I', 'AGG': 'R', 'CCT': 'P', 'ACT': 'T', 'AGC': 'S', 'AAG': 'K', 'AGA': 'R', 'CAT': 'H', 'AAT': 'N', 'ATT': 'I', 'CTG': 'L', 'CTA': 'L', 'CTC': 'L', 'CAC': 'H', 'AAA': 'K', 'CCG': 'P', 'AGT': 'S', 'CCA': 'P', 'CAA': 'Q', 'CCC': 'P', 'TAT': 'Y', 'GGT': 'G', 'TGT': 'C', 'CGA': 'R', 'CAG': 'Q', 'TCT': 'S', 'GAT': 'D', 'CGG': 'R', 'TTT': 'F', 'TGC': 'C', 'GGG': 'G', 'TGA': 'C', 'GGA': 'G', 'TGG': 'W', 'GGC': 'G', 'TAC': 'Y', 'TTC': 'F', 'TCG': 'S', 'TTA': 'L', 'TTG': 'L', 'TCC': 'S', 'ACC': 'T', 'TAA': '*', 'GCA': 'A', 'GTA': 'V', 'GCC': 'A', 'GTC': 'V', 'GCG': 'A', 'GTG': 'V', 'GAG': 'E', 'GTT': 'V', 'GCT': 'A', 'GAC': 'D', 'CGT': 'R', 'GAA': 'E', 'TCA': 'S', 'ATG': 'M', 'CGC': 'R'}, 'bacterial':{'CTT': 'L', 'TAG': '*', 'ACA': 'T', 'ACG': 'T', 'ATC': 'I', 'AAC': 'N', 'ATA': 'I', 'AGG': 'R', 'CCT': 'P', 'ACT': 'T', 'AGC': 'S', 'AAG': 'K', 'AGA': 'R', 'CAT': 'H', 'AAT': 'N', 'ATT': 'I', 'CTG': 'L', 'CTA': 'L', 'CTC': 'L', 'CAC': 'H', 'AAA': 'K', 'CCG': 'P', 'AGT': 'S', 'CCA': 'P', 'CAA': 'Q', 'CCC': 'P', 'TAT': 'Y', 'GGT': 'G', 'TGT': 'C', 'CGA': 'R', 'CAG': 'Q', 'TCT': 'S', 'GAT': 'D', 'CGG': 'R', 'TTT': 'F', 'TGC': 'C', 'GGG': 'G', 'TGA': '*', 'GGA': 'G', 'TGG': 'W', 'GGC': 'G', 'TAC': 'Y', 'TTC': 'F', 'TCG': 'S', 'TTA': 'L', 'TTG': 'L', 'TCC': 'S', 'ACC': 'T', 'TAA': '*', 'GCA': 'A', 'GTA': 'V', 'GCC': 'A', 'GTC': 'V', 'GCG': 'A', 'GTG': 'V', 'GAG': 'E', 'GTT': 'V', 'GCT': 'A', 'GAC': 'D', 'CGT': 'R', 'GAA': 'E', 'TCA': 'S', 'ATG': 'M', 'CGC': 'R'},'yeastNuc':{'CTT': 'L', 'TAG': '*', 'ACA': 'T', 'ACG': 'T', 'ATC': 'I', 'AAC': 'N', 'ATA': 'I', 'AGG': 'R', 'CCT': 'P', 'ACT': 'T', 'AGC': 'S', 'AAG': 'K', 'AGA': 'R', 'CAT': 'H', 'AAT': 'N', 'ATT': 'I', 'CTG': 'S', 'CTA': 'L', 'CTC': 'L', 'CAC': 'H', 'AAA': 'K', 'CCG': 'P', 'AGT': 'S', 'CCA': 'P', 'CAA': 'Q', 'CCC': 'P', 'TAT': 'Y', 'GGT': 'G', 'TGT': 'C', 'CGA': 'R', 'CAG': 'Q', 'TCT': 'S', 'GAT': 'D', 'CGG': 'R', 'TTT': 'F', 'TGC': 'C', 'GGG': 'G', 'TGA': '*', 'GGA': 'G', 'TGG': 'W', 'GGC': 'G', 'TAC': 'Y', 'TTC': 'F', 'TCG': 'S', 'TTA': 'L', 'TTG': 'L', 'TCC': 'S', 'ACC': 'T', 'TAA': '*', 'GCA': 'A', 'GTA': 'V', 'GCC': 'A', 'GTC': 'V', 'GCG': 'A', 'GTG': 'V', 'GAG': 'E', 'GTT': 'V', 'GCT': 'A', 'GAC': 'D', 'CGT': 'R', 'GAA': 'E', 'TCA': 'S', 'ATG': 'M', 'CGC': 'R'}, 'ascidianMt':{'CTT': 'L', 'TAG': '*', 'ACA': 'T', 'ACG': 'T', 'ATC': 'I', 'AAC': 'N', 'ATA': 'M', 'AGG': 'G', 'CCT': 'P', 'ACT': 'T', 'AGC': 'S', 'AAG': 'K', 'AGA': 'G', 'CAT': 'H', 'AAT': 'N', 'ATT': 'I', 'CTG': 'L', 'CTA': 'L', 'CTC': 'L', 'CAC': 'H', 'AAA': 'K', 'CCG': 'P', 'AGT': 'S', 'CCA': 'P', 'CAA': 'Q', 'CCC': 'P', 'TAT': 'Y', 'GGT': 'G', 'TGT': 'C', 'CGA': 'R', 'CAG': 'Q', 'TCT': 'S', 'GAT': 'D', 'CGG': 'R', 'TTT': 'F', 'TGC': 'C', 'GGG': 'G', 'TGA': 'W', 'GGA': 'G', 'TGG': 'W', 'GGC': 'G', 'TAC': 'Y', 'TTC': 'F', 'TCG': 'S', 'TTA': 'L', 'TTG': 'L', 'TCC': 'S', 'ACC': 'T', 'TAA': '*', 'GCA': 'A', 'GTA': 'V', 'GCC': 'A', 'GTC': 'V', 'GCG': 'A', 'GTG': 'V', 'GAG': 'E', 'GTT': 'V', 'GCT': 'A', 'GAC': 'D', 'CGT': 'R', 'GAA': 'E', 'TCA': 'S', 'ATG': 'M', 'CGC': 'R'},'flatwormMt':{'CTT': 'L', 'TAG': '*', 'ACA': 'T', 'ACG': 'T', 'ATC': 'I', 'AAC': 'N', 'ATA': 'I', 'AGG': 'S', 'CCT': 'P', 'ACT': 'T', 'AGC': 'S', 'AAG': 'K', 'AGA': 'S', 'CAT': 'H', 'AAT': 'N', 'ATT': 'I', 'CTG': 'L', 'CTA': 'L', 'CTC': 'L', 'CAC': 'H', 'AAA': 'N', 'CCG': 'P', 'AGT': 'S', 'CCA': 'P', 'CAA': 'Q', 'CCC': 'P', 'TAT': 'Y', 'GGT': 'G', 'TGT': 'C', 'CGA': 'R', 'CAG': 'Q', 'TCT': 'S', 'GAT': 'D', 'CGG': 'R', 'TTT': 'F', 'TGC': 'C', 'GGG': 'G', 'TGA': 'W', 'GGA': 'G', 'TGG': 'W', 'GGC': 'G', 'TAC': 'Y', 'TTC': 'F', 'TCG': 'S', 'TTA': 'L', 'TTG': 'L', 'TCC': 'S', 'ACC': 'T', 'TAA': 'Y', 'GCA': 'A', 'GTA': 'V', 'GCC': 'A', 'GTC': 'V', 'GCG': 'A', 'GTG': 'V', 'GAG': 'E', 'GTT': 'V', 'GCT': 'A', 'GAC': 'D', 'CGT': 'R', 'GAA': 'E', 'TCA': 'S', 'ATG': 'M', 'CGC': 'R'},'chlorophyceanMt':{'CTT': 'L', 'TAG': 'L', 'ACA': 'T', 'ACG': 'T', 'ATC': 'I', 'AAC': 'N', 'ATA': 'I', 'AGG': 'R', 'CCT': 'P', 'ACT': 'T', 'AGC': 'S', 'AAG': 'K', 'AGA': 'R', 'CAT': 'H', 'AAT': 'N', 'ATT': 'I', 'CTG': 'L', 'CTA': 'L', 'CTC': 'L', 'CAC': 'H', 'AAA': 'K', 'CCG': 'P', 'AGT': 'S', 'CCA': 'P', 'CAA': 'Q', 'CCC': 'P', 'TAT': 'Y', 'GGT': 'G', 'TGT': 'C', 'CGA': 'R', 'CAG': 'Q', 'TCT': 'S', 'GAT': 'D', 'CGG': 'R', 'TTT': 'F', 'TGC': 'C', 'GGG': 'G', 'TGA': '*', 'GGA': 'G', 'TGG': 'W', 'GGC': 'G', 'TAC': 'Y', 'TTC': 'F', 'TCG': 'S', 'TTA': 'L', 'TTG': 'L', 'TCC': 'S', 'ACC': 'T', 'TAA': '*', 'GCA': 'A', 'GTA': 'V', 'GCC': 'A', 'GTC': 'V', 'GCG': 'A', 'GTG': 'V', 'GAG': 'E', 'GTT': 'V', 'GCT': 'A', 'GAC': 'D', 'CGT': 'R', 'GAA': 'E', 'TCA': 'S', 'ATG': 'M', 'CGC': 'R'},'trematodeMt':{'CTT': 'L', 'TAG': '*', 'ACA': 'T', 'ACG': 'T', 'ATC': 'I', 'AAC': 'N', 'ATA': 'M', 'AGG': 'S', 'CCT': 'P', 'ACT': 'T', 'AGC': 'S', 'AAG': 'K', 'AGA': 'S', 'CAT': 'H', 'AAT': 'N', 'ATT': 'I', 'CTG': 'L', 'CTA': 'L', 'CTC': 'L', 'CAC': 'H', 'AAA': 'N', 'CCG': 'P', 'AGT': 'S', 'CCA': 'P', 'CAA': 'Q', 'CCC': 'P', 'TAT': 'Y', 'GGT': 'G', 'TGT': 'C', 'CGA': 'R', 'CAG': 'Q', 'TCT': 'S', 'GAT': 'D', 'CGG': 'R', 'TTT': 'F', 'TGC': 'C', 'GGG': 'G', 'TGA': 'W', 'GGA': 'G', 'TGG': 'W', 'GGC': 'G', 'TAC': 'Y', 'TTC': 'F', 'TCG': 'S', 'TTA': 'L', 'TTG': 'L', 'TCC': 'S', 'ACC': 'T', 'TAA': '*', 'GCA': 'A', 'GTA': 'V', 'GCC': 'A', 'GTC': 'V', 'GCG': 'A', 'GTG': 'V', 'GAG': 'E', 'GTT': 'V', 'GCT': 'A', 'GAC': 'D', 'CGT': 'R', 'GAA': 'E', 'TCA': 'S', 'ATG': 'M', 'CGC': 'R'},'pterobranchiaMt':{'CTT': 'L', 'TAG': '*', 'ACA': 'T', 'ACG': 'T', 'ATC': 'I', 'AAC': 'N', 'ATA': 'I', 'AGG': 'K', 'CCT': 'P', 'ACT': 'T', 'AGC': 'S', 'AAG': 'K', 'AGA': 'S', 'CAT': 'H', 'AAT': 'N', 'ATT': 'I', 'CTG': 'L', 'CTA': 'L', 'CTC': 'L', 'CAC': 'H', 'AAA': 'K', 'CCG': 'P', 'AGT': 'S', 'CCA': 'P', 'CAA': 'Q', 'CCC': 'P', 'TAT': 'Y', 'GGT': 'G', 'TGT': 'C', 'CGA': 'R', 'CAG': 'Q', 'TCT': 'S', 'GAT': 'D', 'CGG': 'R', 'TTT': 'F', 'TGC': 'C', 'GGG': 'G', 'TGA': 'W', 'GGA': 'G', 'TGG': 'W', 'GGC': 'G', 'TAC': 'Y', 'TTC': 'F', 'TCG': 'S', 'TTA': 'L', 'TTG': 'L', 'TCC': 'S', 'ACC': 'T', 'TAA': '*', 'GCA': 'A', 'GTA': 'V', 'GCC': 'A', 'GTC': 'V', 'GCG': 'A', 'GTG': 'V', 'GAG': 'E', 'GTT': 'V', 'GCT': 'A', 'GAC': 'D', 'CGT': 'R', 'GAA': 'E', 'TCA': 'S', 'ATG': 'M', 'CGC': 'R'}}
    geneticCode = geneticCodes[code]
    totalSynSites = 0.0
    totalNonsynSites = 0.0
    for codon in codonList:
        if 'N' in codon or '-' in codon:
            totalSynSites += 0.71875
            totalNonsynSites += 2.28125
        else:
            site1 = codon[0]
            site2 = codon[1]
            site3 = codon[2]
            if site1 == 'A':
                mut1 = 'C' + site2 + site3
                mut2 = 'G' + site2 + site3
                mut3 = 'T' + site2 + site3
            elif site1 == 'C':
                mut1 = 'A' + site2 + site3
                mut2 = 'G' + site2 + site3
                mut3 = 'T' + site2 + site3
            elif site1 == 'G':
                mut1 = 'A' + site2 + site3
                mut2 = 'C' + site2 + site3
                mut3 = 'T' + site2 + site3
            elif site1 == 'T':
                mut1 = 'A' + site2 + site3
                mut2 = 'C' + site2 + site3
                mut3 = 'G' + site2 + site3
            if site2 == 'A':
                mut4 = site1 + 'C' + site3
                mut5 = site1 + 'G' + site3
                mut6 = site1 + 'T' + site3
            elif site2 == 'C':
                mut4 = site1 + 'A' + site3
                mut5 = site1 + 'G' + site3
                mut6 = site1 + 'T' + site3
            elif site2 == 'G':
                mut4 = site1 + 'A' + site3
                mut5 = site1 + 'C' + site3
                mut6 = site1 + 'T' + site3
            elif site2 == 'T':
                mut4 = site1 + 'A' + site3
                mut5 = site1 + 'C' + site3
                mut6 = site1 + 'G' + site3
            if site3 == 'A':
                mut7 = site1 + site2 + 'C'
                mut8 = site1 + site2 + 'G'
                mut9 = site1 + site2 + 'T'
            elif site3 == 'C':
                mut7 = site1 + site2 + 'A'
                mut8 = site1 + site2 + 'G'
                mut9 = site1 + site2 + 'T'
            elif site3 == 'G':
                mut7 = site1 + site2 + 'A'
                mut8 = site1 + site2 + 'C'
                mut9 = site1 + site2 + 'T'
            elif site3 == 'T':
                mut7 = site1 + site2 + 'A'
                mut8 = site1 + site2 + 'C'
                mut9 = site1 + site2 + 'G'
            aaList = [geneticCode[mut1],geneticCode[mut2],geneticCode[mut3], geneticCode[mut4],geneticCode[mut5],geneticCode[mut6],geneticCode[mut7],geneticCode[mut8],geneticCode[mut9]]
            currAA = geneticCode[codon]
            synSites = 0.0
            nonsynSites = 0.0
            for aa in aaList:
                if aa == currAA:
                    synSites += 1.0
                else:
                    nonsynSites += 1.0
            synSites = synSites/3.0
            nonsynSites = nonsynSites/3.0
            totalSynSites += synSites
            totalNonsynSites += nonsynSites
    return (totalSynSites,totalNonsynSites)
        
#popGene(sys.argv[1])    